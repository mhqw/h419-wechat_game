cc.Class({
    extends: cc.Component,

    properties: {
        // player:{
        //     type: cc.Node,
        //     default: null,
        // }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    onTouchStart(t) {

    },

    onTouchMove(t) {
        var delta = t.getDelta();
        this.node.x += delta.x;
        this.node.y += delta.y;
    },

    onTouchEnd(t) {

    },

    start() {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
    },

    update(dt) {
        if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
            this.node.x = cc.winSize.width / 2 - this.node.width / 2;
        }
        if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
            this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
        }
    },
});

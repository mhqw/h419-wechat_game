const { ccclass, property } = cc._decorator;

@ccclass
export default class Main extends cc.Component {

    @property(cc.Node)
    player: cc.Node = null;

    @property(cc.Node)
    rocker: cc.Node = null;

    @property(cc.Node)
    rocker_stick: cc.Node = null;

    // @property(number)
    // speed_ctrl: number = 1;

    rocker_max_r: number = 60;
    rocker_touched: boolean = false;
    touch_location: cc.Vec2 = null;
    touch_position: cc.Vec2 = null;
    touch_distance: number = null;
    rocker_x: number = null;
    rocker_y: number = null;

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.rocker.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.rocker.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.rocker.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        this.rocker.on(cc.Node.EventType.TOUCH_END, this.onTouchCancel, this);
    }

    start() {

    }

    onTouchStart(e: cc.Touch) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
        if (this.touch_distance <= this.rocker_max_r) {
            this.rocker_touched = true;
        }
    }

    onTouchMove(e: cc.Touch) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
    }

    onTouchCancel(e: cc.Touch) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    }

    onTouchEnd(e: cc.Touch) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    }

    update(dt: number) {
        if (this.rocker_touched) {
            if (this.touch_distance <= this.rocker_max_r) {
                //摇杆在圈内
                this.rocker_stick.x = this.touch_position.x + this.rocker.x;
                this.rocker_stick.y = this.touch_position.y + this.rocker.y;
            }
            else {
                //摇杆在圈边
                let p = this.touch_position.normalize();
                this.rocker_stick.x = p.x * this.rocker_max_r + this.rocker.x;
                this.rocker_stick.y = p.y * this.rocker_max_r + this.rocker.y;
            }
        }

        this.rocker_x = this.rocker_stick.x - this.rocker.x;
        this.rocker_y = this.rocker_stick.y - this.rocker.y;

        this.player.x += 0.05 * this.rocker_x ;
        this.player.y += 0.05 * this.rocker_y ;
    }
}

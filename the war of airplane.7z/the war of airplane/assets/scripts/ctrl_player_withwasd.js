cc.Class({
    extends: cc.Component,

    properties: {
        dir: {
            type: require("ctrl_player_withwasd_p2"),
            default: null,
        },

        maxSpeed: 0,
        accle: 0,
    },

    start() {
        this.xSpeed = 0;
        this.ySpeed = 0;
    },

    update(dt) {
        if (this.dir.onLeft) {
            this.xSpeed -= this.accle * dt;
        }
        else if (this.dir.onRight) {
            this.xSpeed += this.accle * dt;
        }
        else {
            this.xSpeed = 0;
        }
        if (this.dir.onDown) {
            this.ySpeed -= this.accle * dt;
        }
        else if (this.dir.onUp) {
            this.ySpeed += this.accle * dt;
        }
        else {
            this.ySpeed = 0;
        }

        if (Math.abs(this.xSpeed) > this.maxSpeed) {
            this.xSpeed = this.maxSpeed * this.xSpeed / Math.abs(this.xSpeed);
        }
        if (Math.abs(this.ySpeed) > this.maxSpeed) {
            this.ySpeed = this.maxSpeed * this.ySpeed / Math.abs(this.ySpeed);
        }

        this.node.x += this.xSpeed * dt;
        this.node.y += this.ySpeed * dt;
    },
});

cc.Class({
    extends: cc.Component,

    properties: {
        left: {
            type: cc.Node,
            default: null,
        },
        right: {
            type: cc.Node,
            default: null,
        },
        up:{
            type: cc.Node,
            default: null,
        },
        down:{
            type: cc.Node,
            default: null,
        }
    },

    onLeftStart(){
        this.onLeft = true;
    },

    onLeftEnd(){
        this.onLeft = false;
    },

    onRightStart(){
        this.onRight = true;
    },

    onRightEnd(){
        this.onRight = false;
    },

    onUpStart(){
        this.onUp = true;
    },

    onUpEnd(){
        this.onUp = false;
    },

    onDownStart(){
        this.onDown = true;
    },

    onDownEnd(){
        this.onDown = false;
    },

    start () {
        this.onLeft = false;
        this.onRight = false;
        this.onUp = false;
        this.onDown = false;

        this.left.on(cc.Node.EventType.TOUCH_START,this.onLeftStart,this);
        this.left.on(cc.Node.EventType.TOUCH_END,this.onLeftEnd,this);
        this.right.on(cc.Node.EventType.TOUCH_START,this.onRightStart,this);
        this.right.on(cc.Node.EventType.TOUCH_END,this.onRightEnd,this);
        this.up.on(cc.Node.EventType.TOUCH_START,this.onUpStart,this);
        this.up.on(cc.Node.EventType.TOUCH_END,this.onUpEnd,this);
        this.down.on(cc.Node.EventType.TOUCH_START,this.onDownStart,this);
        this.down.on(cc.Node.EventType.TOUCH_END,this.onDownEnd,this);
    },

    // update (dt) {},
});

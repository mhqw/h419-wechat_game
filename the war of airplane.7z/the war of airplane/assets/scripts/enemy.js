cc.Class({
    extends: cc.Component,

    properties: {

    },

    onLoad() {
        this.dir = Math.random() > 0.5 ? 1 : -1;
        this.xSpeed = 50 + 120 * Math.random();
        this.ySpeed = 50 + 50 * Math.random();
        this.hp = 40 + Math.floor(60 * Math.random());
    },

    start() {
        this.hpLab = this.node.getComponentInChildren(cc.Label);
        this.hpLab.string = this.hp + '';
        // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
    },

    onCollisionEnter(other, self) {
        this.hp -= 1;
        if (this.hp <= 0) {
            this.node.destroy();
        }
        this.hpLab.string = this.hp + '';
    },

    update(dt) {
        //左右反弹
        if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
            this.dir = -1;
        }
        if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
            this.dir = 1;
        }

        this.node.x += this.dir * this.xSpeed * dt;
        this.node.y -= this.ySpeed * dt;

        //再次出现
        if (this.node.y < -800) {
            this.node.y = 800;
        }
        // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
        // console.log('this.xSpeed = ',this.xSpeed);
        // console.log('this.ySpeed = ',this.ySpeed);
        // console.log('this.dir = ',this.dir);
    },
});

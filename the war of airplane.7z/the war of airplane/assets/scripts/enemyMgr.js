cc.Class({
    extends: cc.Component,

    properties: {
        enemy:{
            type: cc.Prefab,
            default: null,
        },
        newEnemyDuration: 6,
    },

    creatOneEnemy(){
        var e = cc.instantiate(this.enemy);
        this.node.addChild(e);
        e.x = -300 + 600 * Math.random();
        e.y = 750;
    },

    start () {
        this.schedule(this.creatOneEnemy,this.newEnemyDuration);
        // this.creatOneEnemy();
    },

});

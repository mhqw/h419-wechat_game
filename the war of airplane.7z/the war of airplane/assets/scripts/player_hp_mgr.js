cc.Class({
    extends: cc.Component,

    properties: {
        player_hp:{
            type: cc.Label,
            default: null,
        }
    },

    onLoad () {
        this.hp = 5 + Math.floor(7 * Math.random());
        this.player_hp.string = this.hp;
    },

    //start () {},

    onCollisionEnter(other,self){
        this.hp -= 1;
        if (this.hp <= 0) {
            cc.director.loadScene('gameover_scene');
        }
        this.player_hp.string = this.hp + '';
    },

    // update (dt) {},
});

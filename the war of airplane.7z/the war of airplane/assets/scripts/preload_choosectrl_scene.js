cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.director.preloadScene('choosectrl_scene');
    },

    enterChoosectrl_scene(){
        cc.director.loadScene('choosectrl_scene');
    },

    start () {

    },

    // update (dt) {},
});

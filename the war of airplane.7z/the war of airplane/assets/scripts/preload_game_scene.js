cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.director.preloadScene('game_scene');
    },

    enterGame_scene(){
        cc.director.loadScene('game_scene');
    },

    start () {
        
    },

    // update (dt) {},
});

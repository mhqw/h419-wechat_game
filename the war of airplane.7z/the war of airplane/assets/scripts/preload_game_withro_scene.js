cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.director.preloadScene('game_withrocker_scene');
    },
    enterGame_withrocker_scene(){
        cc.director.loadScene('game_withrocker_scene');
    },

    start () {

    },

    // update (dt) {},
});

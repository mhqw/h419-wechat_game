cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.director.preloadScene('game_withwasd_scene');
    },

    enterGame_withwasd_scene(){
        cc.director.loadScene('game_withwasd_scene');
    },

    start () {

    },

    // update (dt) {},
});

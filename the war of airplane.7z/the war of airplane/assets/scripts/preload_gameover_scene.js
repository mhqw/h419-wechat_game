cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.director.preloadScene('gameover_scene');
    },

    start () {
        
    },

    // update (dt) {},
});

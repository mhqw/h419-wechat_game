cc.Class({
    extends: cc.Component,

    properties: {
        // player:{
        //     type: cc.Node,
        //     default: null,
        // }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {
    },

    update(dt) {
        //防止跑出屏幕外
        if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
            this.node.x = cc.winSize.width / 2 - this.node.width / 2;
        }
        if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
            this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
        }
        if (this.node.y >= cc.winSize.height / 2 - this.node.height / 2) {
            this.node.y = cc.winSize.height / 2 - this.node.height / 2;
        }
        if (this.node.y <= -cc.winSize.height / 2 + this.node.height / 2) {
            this.node.y = -cc.winSize.height / 2 + this.node.height / 2;
        }
    },
});

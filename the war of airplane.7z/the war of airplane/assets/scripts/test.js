cc.Class({
    extends: cc.Component,

    properties: {
       
    },

    callfunc(){
        console.log("hello");
    },

    start () {
        this.schedule(this.callfunc,0.3);
    },

    // update (dt) {},
});

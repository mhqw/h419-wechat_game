
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/bullet');
require('./assets/scripts/bulletMgr');
require('./assets/scripts/camera_bk');
require('./assets/scripts/ctrl_player');
require('./assets/scripts/ctrl_player_withrocker ');
require('./assets/scripts/ctrl_player_withwasd');
require('./assets/scripts/ctrl_player_withwasd_p2');
require('./assets/scripts/enemy');
require('./assets/scripts/enemyMgr');
require('./assets/scripts/player_hp_mgr');
require('./assets/scripts/preload_choosectrl_scene');
require('./assets/scripts/preload_game_scene');
require('./assets/scripts/preload_game_withro_scene');
require('./assets/scripts/preload_game_withwasd_scene');
require('./assets/scripts/preload_gameover_scene');
require('./assets/scripts/prevent_out');
require('./assets/scripts/test');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/bulletMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5a147DfE6BP1KMMoai9SJjZ', 'bulletMgr');
// scripts/bulletMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    bullet: {
      type: cc.Prefab,
      "default": null
    },
    player: {
      type: cc.Node,
      "default": null
    },
    shootDuration: 0.3
  },
  onLoad: function onLoad() {
    cc.director.getCollisionManager().enabled = true;
    this.pool = new cc.NodePool('bullet');

    for (var i = 0; i < 100; i++) {
      this.pool.put(cc.instantiate(this.bullet));
    }
  },
  start: function start() {
    this.schedule(this.creatManyBullet, this.shootDuration);
  },
  creatManyBullet: function creatManyBullet() {
    var px = this.player.x;
    var py = this.player.y;
    var offset = 55;
    this.creatOneBullet(px, py);
    this.creatOneBullet(px - offset, py);
    this.creatOneBullet(px + offset, py);
  },
  creatOneBullet: function creatOneBullet(x, y) {
    var b = this.pool.get(this.pool);
    if (!b) b = cc.instantiate(this.bullet);
    b.parent = this.node;
    b.x = x;
    b.y = y + 50;
  } //update(dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYnVsbGV0TWdyLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYnVsbGV0IiwidHlwZSIsIlByZWZhYiIsInBsYXllciIsIk5vZGUiLCJzaG9vdER1cmF0aW9uIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRDb2xsaXNpb25NYW5hZ2VyIiwiZW5hYmxlZCIsInBvb2wiLCJOb2RlUG9vbCIsImkiLCJwdXQiLCJpbnN0YW50aWF0ZSIsInN0YXJ0Iiwic2NoZWR1bGUiLCJjcmVhdE1hbnlCdWxsZXQiLCJweCIsIngiLCJweSIsInkiLCJvZmZzZXQiLCJjcmVhdE9uZUJ1bGxldCIsImIiLCJnZXQiLCJwYXJlbnQiLCJub2RlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFFO0FBQ0pDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQURMO0FBRUosaUJBQVM7QUFGTCxLQURBO0FBS1JDLElBQUFBLE1BQU0sRUFBRTtBQUNKRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1EsSUFETDtBQUVKLGlCQUFTO0FBRkwsS0FMQTtBQVNSQyxJQUFBQSxhQUFhLEVBQUU7QUFUUCxHQUhQO0FBZUxDLEVBQUFBLE1BZkssb0JBZUk7QUFDTFYsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLG1CQUFaLEdBQWtDQyxPQUFsQyxHQUE0QyxJQUE1QztBQUNBLFNBQUtDLElBQUwsR0FBWSxJQUFJZCxFQUFFLENBQUNlLFFBQVAsQ0FBZ0IsUUFBaEIsQ0FBWjs7QUFDQSxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsR0FBcEIsRUFBeUJBLENBQUMsRUFBMUIsRUFBOEI7QUFDMUIsV0FBS0YsSUFBTCxDQUFVRyxHQUFWLENBQWNqQixFQUFFLENBQUNrQixXQUFILENBQWUsS0FBS2QsTUFBcEIsQ0FBZDtBQUNIO0FBQ0osR0FyQkk7QUF1QkxlLEVBQUFBLEtBdkJLLG1CQXVCRztBQUNKLFNBQUtDLFFBQUwsQ0FBYyxLQUFLQyxlQUFuQixFQUFvQyxLQUFLWixhQUF6QztBQUNILEdBekJJO0FBMkJMWSxFQUFBQSxlQTNCSyw2QkEyQmE7QUFDZCxRQUFJQyxFQUFFLEdBQUcsS0FBS2YsTUFBTCxDQUFZZ0IsQ0FBckI7QUFDQSxRQUFJQyxFQUFFLEdBQUcsS0FBS2pCLE1BQUwsQ0FBWWtCLENBQXJCO0FBQ0EsUUFBSUMsTUFBTSxHQUFHLEVBQWI7QUFDQSxTQUFLQyxjQUFMLENBQW9CTCxFQUFwQixFQUF3QkUsRUFBeEI7QUFDQSxTQUFLRyxjQUFMLENBQW9CTCxFQUFFLEdBQUdJLE1BQXpCLEVBQWlDRixFQUFqQztBQUNBLFNBQUtHLGNBQUwsQ0FBb0JMLEVBQUUsR0FBR0ksTUFBekIsRUFBaUNGLEVBQWpDO0FBQ0gsR0FsQ0k7QUFvQ0xHLEVBQUFBLGNBcENLLDBCQW9DVUosQ0FwQ1YsRUFvQ2FFLENBcENiLEVBb0NnQjtBQUNqQixRQUFJRyxDQUFDLEdBQUcsS0FBS2QsSUFBTCxDQUFVZSxHQUFWLENBQWMsS0FBS2YsSUFBbkIsQ0FBUjtBQUNBLFFBQUksQ0FBQ2MsQ0FBTCxFQUNJQSxDQUFDLEdBQUc1QixFQUFFLENBQUNrQixXQUFILENBQWUsS0FBS2QsTUFBcEIsQ0FBSjtBQUNKd0IsSUFBQUEsQ0FBQyxDQUFDRSxNQUFGLEdBQVcsS0FBS0MsSUFBaEI7QUFDQUgsSUFBQUEsQ0FBQyxDQUFDTCxDQUFGLEdBQU1BLENBQU47QUFDQUssSUFBQUEsQ0FBQyxDQUFDSCxDQUFGLEdBQU1BLENBQUMsR0FBRyxFQUFWO0FBQ0gsR0EzQ0ksQ0E4Q0w7O0FBOUNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgYnVsbGV0OiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHBsYXllcjoge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2hvb3REdXJhdGlvbjogMC4zLFxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucG9vbCA9IG5ldyBjYy5Ob2RlUG9vbCgnYnVsbGV0Jyk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDA7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLnBvb2wucHV0KGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0KSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuY3JlYXRNYW55QnVsbGV0LCB0aGlzLnNob290RHVyYXRpb24pO1xyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdE1hbnlCdWxsZXQoKSB7XHJcbiAgICAgICAgbGV0IHB4ID0gdGhpcy5wbGF5ZXIueDtcclxuICAgICAgICBsZXQgcHkgPSB0aGlzLnBsYXllci55O1xyXG4gICAgICAgIGxldCBvZmZzZXQgPSA1NTtcclxuICAgICAgICB0aGlzLmNyZWF0T25lQnVsbGV0KHB4LCBweSk7XHJcbiAgICAgICAgdGhpcy5jcmVhdE9uZUJ1bGxldChweCAtIG9mZnNldCwgcHkpO1xyXG4gICAgICAgIHRoaXMuY3JlYXRPbmVCdWxsZXQocHggKyBvZmZzZXQsIHB5KTtcclxuICAgIH0sXHJcblxyXG4gICAgY3JlYXRPbmVCdWxsZXQoeCwgeSkge1xyXG4gICAgICAgIGxldCBiID0gdGhpcy5wb29sLmdldCh0aGlzLnBvb2wpO1xyXG4gICAgICAgIGlmICghYilcclxuICAgICAgICAgICAgYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0KTtcclxuICAgICAgICBiLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICBiLnggPSB4O1xyXG4gICAgICAgIGIueSA9IHkgKyA1MDtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8vdXBkYXRlKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withwasd_p2.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e7fabmMsQFPCKrq+7KgKuXb', 'ctrl_player_withwasd_p2');
// scripts/ctrl_player_withwasd_p2.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    left: {
      type: cc.Node,
      "default": null
    },
    right: {
      type: cc.Node,
      "default": null
    },
    up: {
      type: cc.Node,
      "default": null
    },
    down: {
      type: cc.Node,
      "default": null
    }
  },
  onLeftStart: function onLeftStart() {
    this.onLeft = true;
  },
  onLeftEnd: function onLeftEnd() {
    this.onLeft = false;
  },
  onRightStart: function onRightStart() {
    this.onRight = true;
  },
  onRightEnd: function onRightEnd() {
    this.onRight = false;
  },
  onUpStart: function onUpStart() {
    this.onUp = true;
  },
  onUpEnd: function onUpEnd() {
    this.onUp = false;
  },
  onDownStart: function onDownStart() {
    this.onDown = true;
  },
  onDownEnd: function onDownEnd() {
    this.onDown = false;
  },
  start: function start() {
    this.onLeft = false;
    this.onRight = false;
    this.onUp = false;
    this.onDown = false;
    this.left.on(cc.Node.EventType.TOUCH_START, this.onLeftStart, this);
    this.left.on(cc.Node.EventType.TOUCH_END, this.onLeftEnd, this);
    this.right.on(cc.Node.EventType.TOUCH_START, this.onRightStart, this);
    this.right.on(cc.Node.EventType.TOUCH_END, this.onRightEnd, this);
    this.up.on(cc.Node.EventType.TOUCH_START, this.onUpStart, this);
    this.up.on(cc.Node.EventType.TOUCH_END, this.onUpEnd, this);
    this.down.on(cc.Node.EventType.TOUCH_START, this.onDownStart, this);
    this.down.on(cc.Node.EventType.TOUCH_END, this.onDownEnd, this);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHdhc2RfcDIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJsZWZ0IiwidHlwZSIsIk5vZGUiLCJyaWdodCIsInVwIiwiZG93biIsIm9uTGVmdFN0YXJ0Iiwib25MZWZ0Iiwib25MZWZ0RW5kIiwib25SaWdodFN0YXJ0Iiwib25SaWdodCIsIm9uUmlnaHRFbmQiLCJvblVwU3RhcnQiLCJvblVwIiwib25VcEVuZCIsIm9uRG93blN0YXJ0Iiwib25Eb3duIiwib25Eb3duRW5kIiwic3RhcnQiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiVE9VQ0hfRU5EIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0ZDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURQO0FBRUYsaUJBQVM7QUFGUCxLQURFO0FBS1JDLElBQUFBLEtBQUssRUFBRTtBQUNIRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sSUFETjtBQUVILGlCQUFTO0FBRk4sS0FMQztBQVNSRSxJQUFBQSxFQUFFLEVBQUM7QUFDQ0gsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBRFY7QUFFQyxpQkFBUztBQUZWLEtBVEs7QUFhUkcsSUFBQUEsSUFBSSxFQUFDO0FBQ0RKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURSO0FBRUQsaUJBQVM7QUFGUjtBQWJHLEdBSFA7QUFzQkxJLEVBQUFBLFdBdEJLLHlCQXNCUTtBQUNULFNBQUtDLE1BQUwsR0FBYyxJQUFkO0FBQ0gsR0F4Qkk7QUEwQkxDLEVBQUFBLFNBMUJLLHVCQTBCTTtBQUNQLFNBQUtELE1BQUwsR0FBYyxLQUFkO0FBQ0gsR0E1Qkk7QUE4QkxFLEVBQUFBLFlBOUJLLDBCQThCUztBQUNWLFNBQUtDLE9BQUwsR0FBZSxJQUFmO0FBQ0gsR0FoQ0k7QUFrQ0xDLEVBQUFBLFVBbENLLHdCQWtDTztBQUNSLFNBQUtELE9BQUwsR0FBZSxLQUFmO0FBQ0gsR0FwQ0k7QUFzQ0xFLEVBQUFBLFNBdENLLHVCQXNDTTtBQUNQLFNBQUtDLElBQUwsR0FBWSxJQUFaO0FBQ0gsR0F4Q0k7QUEwQ0xDLEVBQUFBLE9BMUNLLHFCQTBDSTtBQUNMLFNBQUtELElBQUwsR0FBWSxLQUFaO0FBQ0gsR0E1Q0k7QUE4Q0xFLEVBQUFBLFdBOUNLLHlCQThDUTtBQUNULFNBQUtDLE1BQUwsR0FBYyxJQUFkO0FBQ0gsR0FoREk7QUFrRExDLEVBQUFBLFNBbERLLHVCQWtETTtBQUNQLFNBQUtELE1BQUwsR0FBYyxLQUFkO0FBQ0gsR0FwREk7QUFzRExFLEVBQUFBLEtBdERLLG1CQXNESTtBQUNMLFNBQUtYLE1BQUwsR0FBYyxLQUFkO0FBQ0EsU0FBS0csT0FBTCxHQUFlLEtBQWY7QUFDQSxTQUFLRyxJQUFMLEdBQVksS0FBWjtBQUNBLFNBQUtHLE1BQUwsR0FBYyxLQUFkO0FBRUEsU0FBS2hCLElBQUwsQ0FBVW1CLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBL0IsRUFBMkMsS0FBS2YsV0FBaEQsRUFBNEQsSUFBNUQ7QUFDQSxTQUFLTixJQUFMLENBQVVtQixFQUFWLENBQWF2QixFQUFFLENBQUNNLElBQUgsQ0FBUWtCLFNBQVIsQ0FBa0JFLFNBQS9CLEVBQXlDLEtBQUtkLFNBQTlDLEVBQXdELElBQXhEO0FBQ0EsU0FBS0wsS0FBTCxDQUFXZ0IsRUFBWCxDQUFjdkIsRUFBRSxDQUFDTSxJQUFILENBQVFrQixTQUFSLENBQWtCQyxXQUFoQyxFQUE0QyxLQUFLWixZQUFqRCxFQUE4RCxJQUE5RDtBQUNBLFNBQUtOLEtBQUwsQ0FBV2dCLEVBQVgsQ0FBY3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBaEMsRUFBMEMsS0FBS1gsVUFBL0MsRUFBMEQsSUFBMUQ7QUFDQSxTQUFLUCxFQUFMLENBQVFlLEVBQVIsQ0FBV3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBN0IsRUFBeUMsS0FBS1QsU0FBOUMsRUFBd0QsSUFBeEQ7QUFDQSxTQUFLUixFQUFMLENBQVFlLEVBQVIsQ0FBV3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBN0IsRUFBdUMsS0FBS1IsT0FBNUMsRUFBb0QsSUFBcEQ7QUFDQSxTQUFLVCxJQUFMLENBQVVjLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBL0IsRUFBMkMsS0FBS04sV0FBaEQsRUFBNEQsSUFBNUQ7QUFDQSxTQUFLVixJQUFMLENBQVVjLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBL0IsRUFBeUMsS0FBS0wsU0FBOUMsRUFBd0QsSUFBeEQ7QUFDSCxHQXBFSSxDQXNFTDs7QUF0RUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsZWZ0OiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICByaWdodDoge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdXA6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZG93bjp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxlZnRTdGFydCgpe1xyXG4gICAgICAgIHRoaXMub25MZWZ0ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25MZWZ0RW5kKCl7XHJcbiAgICAgICAgdGhpcy5vbkxlZnQgPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25SaWdodFN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5vblJpZ2h0ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25SaWdodEVuZCgpe1xyXG4gICAgICAgIHRoaXMub25SaWdodCA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvblVwU3RhcnQoKXtcclxuICAgICAgICB0aGlzLm9uVXAgPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvblVwRW5kKCl7XHJcbiAgICAgICAgdGhpcy5vblVwID0gZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uRG93blN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5vbkRvd24gPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkRvd25FbmQoKXtcclxuICAgICAgICB0aGlzLm9uRG93biA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5vbkxlZnQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uUmlnaHQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uVXAgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uRG93biA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLmxlZnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vbkxlZnRTdGFydCx0aGlzKTtcclxuICAgICAgICB0aGlzLmxlZnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELHRoaXMub25MZWZ0RW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMucmlnaHQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vblJpZ2h0U3RhcnQsdGhpcyk7XHJcbiAgICAgICAgdGhpcy5yaWdodC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vblJpZ2h0RW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMudXAub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vblVwU3RhcnQsdGhpcyk7XHJcbiAgICAgICAgdGhpcy51cC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vblVwRW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMuZG93bi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCx0aGlzLm9uRG93blN0YXJ0LHRoaXMpO1xyXG4gICAgICAgIHRoaXMuZG93bi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vbkRvd25FbmQsdGhpcyk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd0f17Uy0qRN6o7NUeQlamc0', 'ctrl_player');
// scripts/ctrl_player.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onTouchStart: function onTouchStart(t) {},
  onTouchMove: function onTouchMove(t) {
    var delta = t.getDelta();
    this.node.x += delta.x;
    this.node.y += delta.y;
  },
  onTouchEnd: function onTouchEnd(t) {},
  start: function start() {
    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
  },
  update: function update(dt) {
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvblRvdWNoU3RhcnQiLCJ0Iiwib25Ub3VjaE1vdmUiLCJkZWx0YSIsImdldERlbHRhIiwibm9kZSIsIngiLCJ5Iiwib25Ub3VjaEVuZCIsInN0YXJ0Iiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJUT1VDSF9NT1ZFIiwiVE9VQ0hfRU5EIiwidXBkYXRlIiwiZHQiLCJ3aW5TaXplIiwid2lkdGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBSlEsR0FIUDtBQVVMO0FBRUE7QUFFQUMsRUFBQUEsWUFkSyx3QkFjUUMsQ0FkUixFQWNXLENBRWYsQ0FoQkk7QUFrQkxDLEVBQUFBLFdBbEJLLHVCQWtCT0QsQ0FsQlAsRUFrQlU7QUFDWCxRQUFJRSxLQUFLLEdBQUdGLENBQUMsQ0FBQ0csUUFBRixFQUFaO0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxDQUFWLElBQWVILEtBQUssQ0FBQ0csQ0FBckI7QUFDQSxTQUFLRCxJQUFMLENBQVVFLENBQVYsSUFBZUosS0FBSyxDQUFDSSxDQUFyQjtBQUNILEdBdEJJO0FBd0JMQyxFQUFBQSxVQXhCSyxzQkF3Qk1QLENBeEJOLEVBd0JTLENBRWIsQ0ExQkk7QUE0QkxRLEVBQUFBLEtBNUJLLG1CQTRCRztBQUNKLFNBQUtKLElBQUwsQ0FBVUssRUFBVixDQUFhZCxFQUFFLENBQUNlLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBL0IsRUFBNEMsS0FBS2IsWUFBakQsRUFBK0QsSUFBL0Q7QUFDQSxTQUFLSyxJQUFMLENBQVVLLEVBQVYsQ0FBYWQsRUFBRSxDQUFDZSxJQUFILENBQVFDLFNBQVIsQ0FBa0JFLFVBQS9CLEVBQTJDLEtBQUtaLFdBQWhELEVBQTZELElBQTdEO0FBQ0EsU0FBS0csSUFBTCxDQUFVSyxFQUFWLENBQWFkLEVBQUUsQ0FBQ2UsSUFBSCxDQUFRQyxTQUFSLENBQWtCRyxTQUEvQixFQUEwQyxLQUFLUCxVQUEvQyxFQUEyRCxJQUEzRDtBQUNILEdBaENJO0FBa0NMUSxFQUFBQSxNQWxDSyxrQkFrQ0VDLEVBbENGLEVBa0NNO0FBQ1AsUUFBSSxLQUFLWixJQUFMLENBQVVDLENBQVYsSUFBZVYsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUE1RCxFQUErRDtBQUMzRCxXQUFLZCxJQUFMLENBQVVDLENBQVYsR0FBY1YsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUF2RDtBQUNIOztBQUNELFFBQUksS0FBS2QsSUFBTCxDQUFVQyxDQUFWLElBQWUsQ0FBQ1YsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUE3RCxFQUFnRTtBQUM1RCxXQUFLZCxJQUFMLENBQVVDLENBQVYsR0FBYyxDQUFDVixFQUFFLENBQUNzQixPQUFILENBQVdDLEtBQVosR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS2QsSUFBTCxDQUFVYyxLQUFWLEdBQWtCLENBQXhEO0FBQ0g7QUFDSjtBQXpDSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIHBsYXllcjp7XHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgb25Ub3VjaFN0YXJ0KHQpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hNb3ZlKHQpIHtcclxuICAgICAgICB2YXIgZGVsdGEgPSB0LmdldERlbHRhKCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gZGVsdGEueDtcclxuICAgICAgICB0aGlzLm5vZGUueSArPSBkZWx0YS55O1xyXG4gICAgfSxcclxuXHJcbiAgICBvblRvdWNoRW5kKHQpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpO1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPj0gY2Mud2luU2l6ZS53aWR0aCAvIDIgLSB0aGlzLm5vZGUud2lkdGggLyAyKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gY2Mud2luU2l6ZS53aWR0aCAvIDIgLSB0aGlzLm5vZGUud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPD0gLWNjLndpblNpemUud2lkdGggLyAyICsgdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IC1jYy53aW5TaXplLndpZHRoIC8gMiArIHRoaXMubm9kZS53aWR0aCAvIDI7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withwasd.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e6a33WfoxlKsYgiNxLO4bUu', 'ctrl_player_withwasd');
// scripts/ctrl_player_withwasd.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    dir: {
      type: require("ctrl_player_withwasd_p2"),
      "default": null
    },
    maxSpeed: 0,
    accle: 0
  },
  start: function start() {
    this.xSpeed = 0;
    this.ySpeed = 0;
  },
  update: function update(dt) {
    if (this.dir.onLeft) {
      this.xSpeed -= this.accle * dt;
    } else if (this.dir.onRight) {
      this.xSpeed += this.accle * dt;
    } else {
      this.xSpeed = 0;
    }

    if (this.dir.onDown) {
      this.ySpeed -= this.accle * dt;
    } else if (this.dir.onUp) {
      this.ySpeed += this.accle * dt;
    } else {
      this.ySpeed = 0;
    }

    if (Math.abs(this.xSpeed) > this.maxSpeed) {
      this.xSpeed = this.maxSpeed * this.xSpeed / Math.abs(this.xSpeed);
    }

    if (Math.abs(this.ySpeed) > this.maxSpeed) {
      this.ySpeed = this.maxSpeed * this.ySpeed / Math.abs(this.ySpeed);
    }

    this.node.x += this.xSpeed * dt;
    this.node.y += this.ySpeed * dt;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHdhc2QuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJkaXIiLCJ0eXBlIiwicmVxdWlyZSIsIm1heFNwZWVkIiwiYWNjbGUiLCJzdGFydCIsInhTcGVlZCIsInlTcGVlZCIsInVwZGF0ZSIsImR0Iiwib25MZWZ0Iiwib25SaWdodCIsIm9uRG93biIsIm9uVXAiLCJNYXRoIiwiYWJzIiwibm9kZSIsIngiLCJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsR0FBRyxFQUFFO0FBQ0RDLE1BQUFBLElBQUksRUFBRUMsT0FBTyxDQUFDLHlCQUFELENBRFo7QUFFRCxpQkFBUztBQUZSLEtBREc7QUFNUkMsSUFBQUEsUUFBUSxFQUFFLENBTkY7QUFPUkMsSUFBQUEsS0FBSyxFQUFFO0FBUEMsR0FIUDtBQWFMQyxFQUFBQSxLQWJLLG1CQWFHO0FBQ0osU0FBS0MsTUFBTCxHQUFjLENBQWQ7QUFDQSxTQUFLQyxNQUFMLEdBQWMsQ0FBZDtBQUNILEdBaEJJO0FBa0JMQyxFQUFBQSxNQWxCSyxrQkFrQkVDLEVBbEJGLEVBa0JNO0FBQ1AsUUFBSSxLQUFLVCxHQUFMLENBQVNVLE1BQWIsRUFBcUI7QUFDakIsV0FBS0osTUFBTCxJQUFlLEtBQUtGLEtBQUwsR0FBYUssRUFBNUI7QUFDSCxLQUZELE1BR0ssSUFBSSxLQUFLVCxHQUFMLENBQVNXLE9BQWIsRUFBc0I7QUFDdkIsV0FBS0wsTUFBTCxJQUFlLEtBQUtGLEtBQUwsR0FBYUssRUFBNUI7QUFDSCxLQUZJLE1BR0E7QUFDRCxXQUFLSCxNQUFMLEdBQWMsQ0FBZDtBQUNIOztBQUNELFFBQUksS0FBS04sR0FBTCxDQUFTWSxNQUFiLEVBQXFCO0FBQ2pCLFdBQUtMLE1BQUwsSUFBZSxLQUFLSCxLQUFMLEdBQWFLLEVBQTVCO0FBQ0gsS0FGRCxNQUdLLElBQUksS0FBS1QsR0FBTCxDQUFTYSxJQUFiLEVBQW1CO0FBQ3BCLFdBQUtOLE1BQUwsSUFBZSxLQUFLSCxLQUFMLEdBQWFLLEVBQTVCO0FBQ0gsS0FGSSxNQUdBO0FBQ0QsV0FBS0YsTUFBTCxHQUFjLENBQWQ7QUFDSDs7QUFFRCxRQUFJTyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLVCxNQUFkLElBQXdCLEtBQUtILFFBQWpDLEVBQTJDO0FBQ3ZDLFdBQUtHLE1BQUwsR0FBYyxLQUFLSCxRQUFMLEdBQWdCLEtBQUtHLE1BQXJCLEdBQThCUSxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLVCxNQUFkLENBQTVDO0FBQ0g7O0FBQ0QsUUFBSVEsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1IsTUFBZCxJQUF3QixLQUFLSixRQUFqQyxFQUEyQztBQUN2QyxXQUFLSSxNQUFMLEdBQWMsS0FBS0osUUFBTCxHQUFnQixLQUFLSSxNQUFyQixHQUE4Qk8sSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1IsTUFBZCxDQUE1QztBQUNIOztBQUVELFNBQUtTLElBQUwsQ0FBVUMsQ0FBVixJQUFlLEtBQUtYLE1BQUwsR0FBY0csRUFBN0I7QUFDQSxTQUFLTyxJQUFMLENBQVVFLENBQVYsSUFBZSxLQUFLWCxNQUFMLEdBQWNFLEVBQTdCO0FBQ0g7QUEvQ0ksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBkaXI6IHtcclxuICAgICAgICAgICAgdHlwZTogcmVxdWlyZShcImN0cmxfcGxheWVyX3dpdGh3YXNkX3AyXCIpLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIG1heFNwZWVkOiAwLFxyXG4gICAgICAgIGFjY2xlOiAwLFxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnhTcGVlZCA9IDA7XHJcbiAgICAgICAgdGhpcy55U3BlZWQgPSAwO1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5kaXIub25MZWZ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkIC09IHRoaXMuYWNjbGUgKiBkdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5kaXIub25SaWdodCkge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCArPSB0aGlzLmFjY2xlICogZHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmRpci5vbkRvd24pIHtcclxuICAgICAgICAgICAgdGhpcy55U3BlZWQgLT0gdGhpcy5hY2NsZSAqIGR0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmRpci5vblVwKSB7XHJcbiAgICAgICAgICAgIHRoaXMueVNwZWVkICs9IHRoaXMuYWNjbGUgKiBkdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMueVNwZWVkID0gMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChNYXRoLmFicyh0aGlzLnhTcGVlZCkgPiB0aGlzLm1heFNwZWVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkID0gdGhpcy5tYXhTcGVlZCAqIHRoaXMueFNwZWVkIC8gTWF0aC5hYnModGhpcy54U3BlZWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoTWF0aC5hYnModGhpcy55U3BlZWQpID4gdGhpcy5tYXhTcGVlZCkge1xyXG4gICAgICAgICAgICB0aGlzLnlTcGVlZCA9IHRoaXMubWF4U3BlZWQgKiB0aGlzLnlTcGVlZCAvIE1hdGguYWJzKHRoaXMueVNwZWVkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy55U3BlZWQgKiBkdDtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/camera_bk.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd958dgWyJRNG5iVSuSy+uNo', 'camera_bk');
// scripts/camera_bk.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // onLoad () {},
  start: function start() {
    var _this = this;

    cc.tween(this.node).repeatForever(cc.tween().to(10, {
      position: cc.v2(0, 1440)
    }).call(function () {
      _this.node.y = 0;
    })).start();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY2FtZXJhX2JrLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJ0d2VlbiIsIm5vZGUiLCJyZXBlYXRGb3JldmVyIiwidG8iLCJwb3NpdGlvbiIsInYyIiwiY2FsbCIsInkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsS0FUSyxtQkFTSTtBQUFBOztBQUNMSixJQUFBQSxFQUFFLENBQUNLLEtBQUgsQ0FBUyxLQUFLQyxJQUFkLEVBQ0tDLGFBREwsQ0FFUVAsRUFBRSxDQUFDSyxLQUFILEdBQ0tHLEVBREwsQ0FDUSxFQURSLEVBQ1c7QUFBQ0MsTUFBQUEsUUFBUSxFQUFFVCxFQUFFLENBQUNVLEVBQUgsQ0FBTSxDQUFOLEVBQVEsSUFBUjtBQUFYLEtBRFgsRUFFS0MsSUFGTCxDQUVVLFlBQUk7QUFBQyxNQUFBLEtBQUksQ0FBQ0wsSUFBTCxDQUFVTSxDQUFWLEdBQWMsQ0FBZDtBQUFnQixLQUYvQixDQUZSLEVBS01SLEtBTE47QUFNSCxHQWhCSSxDQWtCTDs7QUFsQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXHJcbiAgICAgICAgICAgIC5yZXBlYXRGb3JldmVyKFxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4oKVxyXG4gICAgICAgICAgICAgICAgICAgIC50bygxMCx7cG9zaXRpb246IGNjLnYyKDAsMTQ0MCl9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYWxsKCgpPT57dGhpcy5ub2RlLnkgPSAwfSlcclxuICAgICAgICAgICAgKS5zdGFydCgpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/player_hp_mgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8aaa8ubRG9B1JH4VeMARY3p', 'player_hp_mgr');
// scripts/player_hp_mgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player_hp: {
      type: cc.Label,
      "default": null
    }
  },
  onLoad: function onLoad() {
    this.hp = 5 + Math.floor(7 * Math.random());
    this.player_hp.string = this.hp;
  },
  //start () {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.hp -= 1;

    if (this.hp <= 0) {
      cc.director.loadScene('gameover_scene');
    }

    this.player_hp.string = this.hp + '';
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccGxheWVyX2hwX21nci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInBsYXllcl9ocCIsInR5cGUiLCJMYWJlbCIsIm9uTG9hZCIsImhwIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwic3RyaW5nIiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImRpcmVjdG9yIiwibG9hZFNjZW5lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsU0FBUyxFQUFDO0FBQ05DLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQURIO0FBRU4saUJBQVM7QUFGSDtBQURGLEdBSFA7QUFVTEMsRUFBQUEsTUFWSyxvQkFVSztBQUNOLFNBQUtDLEVBQUwsR0FBVSxJQUFJQyxJQUFJLENBQUNDLEtBQUwsQ0FBVyxJQUFJRCxJQUFJLENBQUNFLE1BQUwsRUFBZixDQUFkO0FBQ0EsU0FBS1AsU0FBTCxDQUFlUSxNQUFmLEdBQXdCLEtBQUtKLEVBQTdCO0FBQ0gsR0FiSTtBQWVMO0FBRUFLLEVBQUFBLGdCQWpCSyw0QkFpQllDLEtBakJaLEVBaUJrQkMsSUFqQmxCLEVBaUJ1QjtBQUN4QixTQUFLUCxFQUFMLElBQVcsQ0FBWDs7QUFDQSxRQUFJLEtBQUtBLEVBQUwsSUFBVyxDQUFmLEVBQWtCO0FBQ2RSLE1BQUFBLEVBQUUsQ0FBQ2dCLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixnQkFBdEI7QUFDSDs7QUFDRCxTQUFLYixTQUFMLENBQWVRLE1BQWYsR0FBd0IsS0FBS0osRUFBTCxHQUFVLEVBQWxDO0FBQ0gsR0F2QkksQ0F5Qkw7O0FBekJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgcGxheWVyX2hwOntcclxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWwsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuaHAgPSA1ICsgTWF0aC5mbG9vcig3ICogTWF0aC5yYW5kb20oKSk7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXJfaHAuc3RyaW5nID0gdGhpcy5ocDtcclxuICAgIH0sXHJcblxyXG4gICAgLy9zdGFydCAoKSB7fSxcclxuXHJcbiAgICBvbkNvbGxpc2lvbkVudGVyKG90aGVyLHNlbGYpe1xyXG4gICAgICAgIHRoaXMuaHAgLT0gMTtcclxuICAgICAgICBpZiAodGhpcy5ocCA8PSAwKSB7XHJcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZ2FtZW92ZXJfc2NlbmUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wbGF5ZXJfaHAuc3RyaW5nID0gdGhpcy5ocCArICcnO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/preload_choosectrl_scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '04486d+PyZOWYqz6hgNDzUm', 'preload_choosectrl_scene');
// scripts/preload_choosectrl_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('choosectrl_scene');
  },
  enterChoosectrl_scene: function enterChoosectrl_scene() {
    cc.director.loadScene('choosectrl_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJlbG9hZF9jaG9vc2VjdHJsX3NjZW5lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJwcmVsb2FkU2NlbmUiLCJlbnRlckNob29zZWN0cmxfc2NlbmUiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFPTDtBQUVBQyxFQUFBQSxNQVRLLG9CQVNLO0FBQ05KLElBQUFBLEVBQUUsQ0FBQ0ssUUFBSCxDQUFZQyxZQUFaLENBQXlCLGtCQUF6QjtBQUNILEdBWEk7QUFhTEMsRUFBQUEscUJBYkssbUNBYWtCO0FBQ25CUCxJQUFBQSxFQUFFLENBQUNLLFFBQUgsQ0FBWUcsU0FBWixDQUFzQixrQkFBdEI7QUFDSCxHQWZJO0FBaUJMQyxFQUFBQSxLQWpCSyxtQkFpQkksQ0FFUixDQW5CSSxDQXFCTDs7QUFyQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUoJ2Nob29zZWN0cmxfc2NlbmUnKTtcclxuICAgIH0sXHJcblxyXG4gICAgZW50ZXJDaG9vc2VjdHJsX3NjZW5lKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdjaG9vc2VjdHJsX3NjZW5lJyk7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/preload_gameover_scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f27ed1wkO1D1YrManjtxmGk', 'preload_gameover_scene');
// scripts/preload_gameover_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('gameover_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJlbG9hZF9nYW1lb3Zlcl9zY2VuZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsImRpcmVjdG9yIiwicHJlbG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsTUFUSyxvQkFTSztBQUNOSixJQUFBQSxFQUFFLENBQUNLLFFBQUgsQ0FBWUMsWUFBWixDQUF5QixnQkFBekI7QUFDSCxHQVhJO0FBYUxDLEVBQUFBLEtBYkssbUJBYUksQ0FFUixDQWZJLENBaUJMOztBQWpCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLnByZWxvYWRTY2VuZSgnZ2FtZW92ZXJfc2NlbmUnKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/preload_game_withro_scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fee3bb4mHdKH7BC1GrMifFc', 'preload_game_withro_scene');
// scripts/preload_game_withro_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('game_withrocker_scene');
  },
  enterGame_withrocker_scene: function enterGame_withrocker_scene() {
    cc.director.loadScene('game_withrocker_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJlbG9hZF9nYW1lX3dpdGhyb19zY2VuZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIm9uTG9hZCIsImRpcmVjdG9yIiwicHJlbG9hZFNjZW5lIiwiZW50ZXJHYW1lX3dpdGhyb2NrZXJfc2NlbmUiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFPTDtBQUVBQyxFQUFBQSxNQVRLLG9CQVNLO0FBQ05KLElBQUFBLEVBQUUsQ0FBQ0ssUUFBSCxDQUFZQyxZQUFaLENBQXlCLHVCQUF6QjtBQUNILEdBWEk7QUFZTEMsRUFBQUEsMEJBWkssd0NBWXVCO0FBQ3hCUCxJQUFBQSxFQUFFLENBQUNLLFFBQUgsQ0FBWUcsU0FBWixDQUFzQix1QkFBdEI7QUFDSCxHQWRJO0FBZ0JMQyxFQUFBQSxLQWhCSyxtQkFnQkksQ0FFUixDQWxCSSxDQW9CTDs7QUFwQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUoJ2dhbWVfd2l0aHJvY2tlcl9zY2VuZScpO1xyXG4gICAgfSxcclxuICAgIGVudGVyR2FtZV93aXRocm9ja2VyX3NjZW5lKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lX3dpdGhyb2NrZXJfc2NlbmUnKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/enemy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '84dab/RQzZF2rsLVY7uWlCv', 'enemy');
// scripts/enemy.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {
    this.dir = Math.random() > 0.5 ? 1 : -1;
    this.xSpeed = 50 + 120 * Math.random();
    this.ySpeed = 50 + 50 * Math.random();
    this.hp = 40 + Math.floor(60 * Math.random());
  },
  start: function start() {
    this.hpLab = this.node.getComponentInChildren(cc.Label);
    this.hpLab.string = this.hp + ''; // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.hp -= 1;

    if (this.hp <= 0) {
      this.node.destroy();
    }

    this.hpLab.string = this.hp + '';
  },
  update: function update(dt) {
    //左右反弹
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.dir = -1;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.dir = 1;
    }

    this.node.x += this.dir * this.xSpeed * dt;
    this.node.y -= this.ySpeed * dt; //再次出现

    if (this.node.y < -800) {
      this.node.y = 800;
    } // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
    // console.log('this.xSpeed = ',this.xSpeed);
    // console.log('this.ySpeed = ',this.ySpeed);
    // console.log('this.dir = ',this.dir);

  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZW5lbXkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJkaXIiLCJNYXRoIiwicmFuZG9tIiwieFNwZWVkIiwieVNwZWVkIiwiaHAiLCJmbG9vciIsInN0YXJ0IiwiaHBMYWIiLCJub2RlIiwiZ2V0Q29tcG9uZW50SW5DaGlsZHJlbiIsIkxhYmVsIiwic3RyaW5nIiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImRlc3Ryb3kiLCJ1cGRhdGUiLCJkdCIsIngiLCJ3aW5TaXplIiwid2lkdGgiLCJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU9MQyxFQUFBQSxNQVBLLG9CQU9JO0FBQ0wsU0FBS0MsR0FBTCxHQUFXQyxJQUFJLENBQUNDLE1BQUwsS0FBZ0IsR0FBaEIsR0FBc0IsQ0FBdEIsR0FBMEIsQ0FBQyxDQUF0QztBQUNBLFNBQUtDLE1BQUwsR0FBYyxLQUFLLE1BQU1GLElBQUksQ0FBQ0MsTUFBTCxFQUF6QjtBQUNBLFNBQUtFLE1BQUwsR0FBYyxLQUFLLEtBQUtILElBQUksQ0FBQ0MsTUFBTCxFQUF4QjtBQUNBLFNBQUtHLEVBQUwsR0FBVSxLQUFLSixJQUFJLENBQUNLLEtBQUwsQ0FBVyxLQUFLTCxJQUFJLENBQUNDLE1BQUwsRUFBaEIsQ0FBZjtBQUNILEdBWkk7QUFjTEssRUFBQUEsS0FkSyxtQkFjRztBQUNKLFNBQUtDLEtBQUwsR0FBYSxLQUFLQyxJQUFMLENBQVVDLHNCQUFWLENBQWlDZixFQUFFLENBQUNnQixLQUFwQyxDQUFiO0FBQ0EsU0FBS0gsS0FBTCxDQUFXSSxNQUFYLEdBQW9CLEtBQUtQLEVBQUwsR0FBVSxFQUE5QixDQUZJLENBR0o7QUFDSCxHQWxCSTtBQW9CTFEsRUFBQUEsZ0JBcEJLLDRCQW9CWUMsS0FwQlosRUFvQm1CQyxJQXBCbkIsRUFvQnlCO0FBQzFCLFNBQUtWLEVBQUwsSUFBVyxDQUFYOztBQUNBLFFBQUksS0FBS0EsRUFBTCxJQUFXLENBQWYsRUFBa0I7QUFDZCxXQUFLSSxJQUFMLENBQVVPLE9BQVY7QUFDSDs7QUFDRCxTQUFLUixLQUFMLENBQVdJLE1BQVgsR0FBb0IsS0FBS1AsRUFBTCxHQUFVLEVBQTlCO0FBQ0gsR0ExQkk7QUE0QkxZLEVBQUFBLE1BNUJLLGtCQTRCRUMsRUE1QkYsRUE0Qk07QUFDUDtBQUNBLFFBQUksS0FBS1QsSUFBTCxDQUFVVSxDQUFWLElBQWV4QixFQUFFLENBQUN5QixPQUFILENBQVdDLEtBQVgsR0FBbUIsQ0FBbkIsR0FBdUIsS0FBS1osSUFBTCxDQUFVWSxLQUFWLEdBQWtCLENBQTVELEVBQStEO0FBQzNELFdBQUtyQixHQUFMLEdBQVcsQ0FBQyxDQUFaO0FBQ0g7O0FBQ0QsUUFBSSxLQUFLUyxJQUFMLENBQVVVLENBQVYsSUFBZSxDQUFDeEIsRUFBRSxDQUFDeUIsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtaLElBQUwsQ0FBVVksS0FBVixHQUFrQixDQUE3RCxFQUFnRTtBQUM1RCxXQUFLckIsR0FBTCxHQUFXLENBQVg7QUFDSDs7QUFFRCxTQUFLUyxJQUFMLENBQVVVLENBQVYsSUFBZSxLQUFLbkIsR0FBTCxHQUFXLEtBQUtHLE1BQWhCLEdBQXlCZSxFQUF4QztBQUNBLFNBQUtULElBQUwsQ0FBVWEsQ0FBVixJQUFlLEtBQUtsQixNQUFMLEdBQWNjLEVBQTdCLENBVk8sQ0FZUDs7QUFDQSxRQUFJLEtBQUtULElBQUwsQ0FBVWEsQ0FBVixHQUFjLENBQUMsR0FBbkIsRUFBd0I7QUFDcEIsV0FBS2IsSUFBTCxDQUFVYSxDQUFWLEdBQWMsR0FBZDtBQUNILEtBZk0sQ0FnQlA7QUFDQTtBQUNBO0FBQ0E7O0FBQ0g7QUFoREksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICB0aGlzLmRpciA9IE1hdGgucmFuZG9tKCkgPiAwLjUgPyAxIDogLTE7XHJcbiAgICAgICAgdGhpcy54U3BlZWQgPSA1MCArIDEyMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgdGhpcy55U3BlZWQgPSA1MCArIDUwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICB0aGlzLmhwID0gNDAgKyBNYXRoLmZsb29yKDYwICogTWF0aC5yYW5kb20oKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuaHBMYWIgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50SW5DaGlsZHJlbihjYy5MYWJlbCk7XHJcbiAgICAgICAgdGhpcy5ocExhYi5zdHJpbmcgPSB0aGlzLmhwICsgJyc7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUih0aGlzLm5vZGUuZ2V0UG9zaXRpb24oKSkpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkNvbGxpc2lvbkVudGVyKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgdGhpcy5ocCAtPSAxO1xyXG4gICAgICAgIGlmICh0aGlzLmhwIDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5ocExhYi5zdHJpbmcgPSB0aGlzLmhwICsgJyc7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIC8v5bem5Y+z5Y+N5by5XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54ID49IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLmRpciA9IC0xO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPD0gLWNjLndpblNpemUud2lkdGggLyAyICsgdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLmRpciA9IDE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5vZGUueCArPSB0aGlzLmRpciAqIHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgLT0gdGhpcy55U3BlZWQgKiBkdDtcclxuXHJcbiAgICAgICAgLy/lho3mrKHlh7rnjrBcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPCAtODAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS55ID0gODAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKHRoaXMubm9kZS5nZXRQb3NpdGlvbigpKSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMueFNwZWVkID0gJyx0aGlzLnhTcGVlZCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMueVNwZWVkID0gJyx0aGlzLnlTcGVlZCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuZGlyID0gJyx0aGlzLmRpcik7XHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/preload_game_withwasd_scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '41724Dd2spJL6CjO9e5Z+3h', 'preload_game_withwasd_scene');
// scripts/preload_game_withwasd_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('game_withwasd_scene');
  },
  enterGame_withwasd_scene: function enterGame_withwasd_scene() {
    cc.director.loadScene('game_withwasd_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJlbG9hZF9nYW1lX3dpdGh3YXNkX3NjZW5lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJwcmVsb2FkU2NlbmUiLCJlbnRlckdhbWVfd2l0aHdhc2Rfc2NlbmUiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFPTDtBQUVBQyxFQUFBQSxNQVRLLG9CQVNLO0FBQ05KLElBQUFBLEVBQUUsQ0FBQ0ssUUFBSCxDQUFZQyxZQUFaLENBQXlCLHFCQUF6QjtBQUNILEdBWEk7QUFhTEMsRUFBQUEsd0JBYkssc0NBYXFCO0FBQ3RCUCxJQUFBQSxFQUFFLENBQUNLLFFBQUgsQ0FBWUcsU0FBWixDQUFzQixxQkFBdEI7QUFDSCxHQWZJO0FBaUJMQyxFQUFBQSxLQWpCSyxtQkFpQkksQ0FFUixDQW5CSSxDQXFCTDs7QUFyQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5wcmVsb2FkU2NlbmUoJ2dhbWVfd2l0aHdhc2Rfc2NlbmUnKTtcclxuICAgIH0sXHJcblxyXG4gICAgZW50ZXJHYW1lX3dpdGh3YXNkX3NjZW5lKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lX3dpdGh3YXNkX3NjZW5lJyk7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/enemyMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c29852ieOFAz44vlMnx/RaC', 'enemyMgr');
// scripts/enemyMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    enemy: {
      type: cc.Prefab,
      "default": null
    },
    newEnemyDuration: 6
  },
  creatOneEnemy: function creatOneEnemy() {
    var e = cc.instantiate(this.enemy);
    this.node.addChild(e);
    e.x = -300 + 600 * Math.random();
    e.y = 750;
  },
  start: function start() {
    this.schedule(this.creatOneEnemy, this.newEnemyDuration); // this.creatOneEnemy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZW5lbXlNZ3IuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJlbmVteSIsInR5cGUiLCJQcmVmYWIiLCJuZXdFbmVteUR1cmF0aW9uIiwiY3JlYXRPbmVFbmVteSIsImUiLCJpbnN0YW50aWF0ZSIsIm5vZGUiLCJhZGRDaGlsZCIsIngiLCJNYXRoIiwicmFuZG9tIiwieSIsInN0YXJ0Iiwic2NoZWR1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUM7QUFDRkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRFA7QUFFRixpQkFBUztBQUZQLEtBREU7QUFLUkMsSUFBQUEsZ0JBQWdCLEVBQUU7QUFMVixHQUhQO0FBV0xDLEVBQUFBLGFBWEssMkJBV1U7QUFDWCxRQUFJQyxDQUFDLEdBQUdULEVBQUUsQ0FBQ1UsV0FBSCxDQUFlLEtBQUtOLEtBQXBCLENBQVI7QUFDQSxTQUFLTyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJILENBQW5CO0FBQ0FBLElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNLENBQUMsR0FBRCxHQUFPLE1BQU1DLElBQUksQ0FBQ0MsTUFBTCxFQUFuQjtBQUNBTixJQUFBQSxDQUFDLENBQUNPLENBQUYsR0FBTSxHQUFOO0FBQ0gsR0FoQkk7QUFrQkxDLEVBQUFBLEtBbEJLLG1CQWtCSTtBQUNMLFNBQUtDLFFBQUwsQ0FBYyxLQUFLVixhQUFuQixFQUFpQyxLQUFLRCxnQkFBdEMsRUFESyxDQUVMO0FBQ0g7QUFyQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBlbmVteTp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG5ld0VuZW15RHVyYXRpb246IDYsXHJcbiAgICB9LFxyXG5cclxuICAgIGNyZWF0T25lRW5lbXkoKXtcclxuICAgICAgICB2YXIgZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZW5lbXkpO1xyXG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChlKTtcclxuICAgICAgICBlLnggPSAtMzAwICsgNjAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBlLnkgPSA3NTA7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuY3JlYXRPbmVFbmVteSx0aGlzLm5ld0VuZW15RHVyYXRpb24pO1xyXG4gICAgICAgIC8vIHRoaXMuY3JlYXRPbmVFbmVteSgpO1xyXG4gICAgfSxcclxuXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/preload_game_scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8a448yQuLhNSK7dWkIlVNyx', 'preload_game_scene');
// scripts/preload_game_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('game_scene');
  },
  enterGame_scene: function enterGame_scene() {
    cc.director.loadScene('game_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJlbG9hZF9nYW1lX3NjZW5lLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJwcmVsb2FkU2NlbmUiLCJlbnRlckdhbWVfc2NlbmUiLCJsb2FkU2NlbmUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFLEVBSFA7QUFPTDtBQUVBQyxFQUFBQSxNQVRLLG9CQVNLO0FBQ05KLElBQUFBLEVBQUUsQ0FBQ0ssUUFBSCxDQUFZQyxZQUFaLENBQXlCLFlBQXpCO0FBQ0gsR0FYSTtBQWFMQyxFQUFBQSxlQWJLLDZCQWFZO0FBQ2JQLElBQUFBLEVBQUUsQ0FBQ0ssUUFBSCxDQUFZRyxTQUFaLENBQXNCLFlBQXRCO0FBQ0gsR0FmSTtBQWlCTEMsRUFBQUEsS0FqQkssbUJBaUJJLENBRVIsQ0FuQkksQ0FxQkw7O0FBckJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IucHJlbG9hZFNjZW5lKCdnYW1lX3NjZW5lJyk7XHJcbiAgICB9LFxyXG5cclxuICAgIGVudGVyR2FtZV9zY2VuZSgpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZ2FtZV9zY2VuZScpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/prevent_out.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '49b717oGXdOE76zneMmdmuQ', 'prevent_out');
// scripts/prevent_out.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    //防止跑出屏幕外
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }

    if (this.node.y >= cc.winSize.height / 2 - this.node.height / 2) {
      this.node.y = cc.winSize.height / 2 - this.node.height / 2;
    }

    if (this.node.y <= -cc.winSize.height / 2 + this.node.height / 2) {
      this.node.y = -cc.winSize.height / 2 + this.node.height / 2;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJldmVudF9vdXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwibm9kZSIsIngiLCJ3aW5TaXplIiwid2lkdGgiLCJ5IiwiaGVpZ2h0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsQ0FDUjtBQUNBO0FBQ0E7QUFDQTtBQUpRLEdBSFA7QUFVTDtBQUVBO0FBRUFDLEVBQUFBLEtBZEssbUJBY0csQ0FDUCxDQWZJO0FBaUJMQyxFQUFBQSxNQWpCSyxrQkFpQkVDLEVBakJGLEVBaUJNO0FBQ1A7QUFDQSxRQUFJLEtBQUtDLElBQUwsQ0FBVUMsQ0FBVixJQUFlUixFQUFFLENBQUNTLE9BQUgsQ0FBV0MsS0FBWCxHQUFtQixDQUFuQixHQUF1QixLQUFLSCxJQUFMLENBQVVHLEtBQVYsR0FBa0IsQ0FBNUQsRUFBK0Q7QUFDM0QsV0FBS0gsSUFBTCxDQUFVQyxDQUFWLEdBQWNSLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtILElBQUwsQ0FBVUcsS0FBVixHQUFrQixDQUF2RDtBQUNIOztBQUNELFFBQUksS0FBS0gsSUFBTCxDQUFVQyxDQUFWLElBQWUsQ0FBQ1IsRUFBRSxDQUFDUyxPQUFILENBQVdDLEtBQVosR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS0gsSUFBTCxDQUFVRyxLQUFWLEdBQWtCLENBQTdELEVBQWdFO0FBQzVELFdBQUtILElBQUwsQ0FBVUMsQ0FBVixHQUFjLENBQUNSLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtILElBQUwsQ0FBVUcsS0FBVixHQUFrQixDQUF4RDtBQUNIOztBQUNELFFBQUksS0FBS0gsSUFBTCxDQUFVSSxDQUFWLElBQWVYLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXRyxNQUFYLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtMLElBQUwsQ0FBVUssTUFBVixHQUFtQixDQUE5RCxFQUFpRTtBQUM3RCxXQUFLTCxJQUFMLENBQVVJLENBQVYsR0FBY1gsRUFBRSxDQUFDUyxPQUFILENBQVdHLE1BQVgsR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS0wsSUFBTCxDQUFVSyxNQUFWLEdBQW1CLENBQXpEO0FBQ0g7O0FBQ0QsUUFBSSxLQUFLTCxJQUFMLENBQVVJLENBQVYsSUFBZSxDQUFDWCxFQUFFLENBQUNTLE9BQUgsQ0FBV0csTUFBWixHQUFxQixDQUFyQixHQUF5QixLQUFLTCxJQUFMLENBQVVLLE1BQVYsR0FBbUIsQ0FBL0QsRUFBa0U7QUFDOUQsV0FBS0wsSUFBTCxDQUFVSSxDQUFWLEdBQWMsQ0FBQ1gsRUFBRSxDQUFDUyxPQUFILENBQVdHLE1BQVosR0FBcUIsQ0FBckIsR0FBeUIsS0FBS0wsSUFBTCxDQUFVSyxNQUFWLEdBQW1CLENBQTFEO0FBQ0g7QUFDSjtBQS9CSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIHBsYXllcjp7XHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIC8v6Ziy5q2i6LeR5Ye65bGP5bmV5aSWXHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54ID49IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54IDw9IC1jYy53aW5TaXplLndpZHRoIC8gMiArIHRoaXMubm9kZS53aWR0aCAvIDIpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSAtY2Mud2luU2l6ZS53aWR0aCAvIDIgKyB0aGlzLm5vZGUud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPj0gY2Mud2luU2l6ZS5oZWlnaHQgLyAyIC0gdGhpcy5ub2RlLmhlaWdodCAvIDIpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnkgPSBjYy53aW5TaXplLmhlaWdodCAvIDIgLSB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS55IDw9IC1jYy53aW5TaXplLmhlaWdodCAvIDIgKyB0aGlzLm5vZGUuaGVpZ2h0IC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueSA9IC1jYy53aW5TaXplLmhlaWdodCAvIDIgKyB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/test.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8d93f/kJcRDtLDg0GMZPuJn', 'test');
// scripts/test.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  callfunc: function callfunc() {
    console.log("hello");
  },
  start: function start() {
    this.schedule(this.callfunc, 0.3);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdGVzdC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNhbGxmdW5jIiwiY29uc29sZSIsImxvZyIsInN0YXJ0Iiwic2NoZWR1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0xDLEVBQUFBLFFBUEssc0JBT0s7QUFDTkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNILEdBVEk7QUFXTEMsRUFBQUEsS0FYSyxtQkFXSTtBQUNMLFNBQUtDLFFBQUwsQ0FBYyxLQUFLSixRQUFuQixFQUE0QixHQUE1QjtBQUNILEdBYkksQ0FlTDs7QUFmSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIGNhbGxmdW5jKCl7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJoZWxsb1wiKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuc2NoZWR1bGUodGhpcy5jYWxsZnVuYywwLjMpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withrocker .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b38acFBUl5MdY2DzGXp3MXp', 'ctrl_player_withrocker ');
// scripts/ctrl_player_withrocker .ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.rocker = null;
        _this.rocker_stick = null;
        // @property(number)
        // speed_ctrl: number = 1;
        _this.rocker_max_r = 60;
        _this.rocker_touched = false;
        _this.touch_location = null;
        _this.touch_position = null;
        _this.touch_distance = null;
        _this.rocker_x = null;
        _this.rocker_y = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    Main.prototype.onLoad = function () {
        this.rocker.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.rocker.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.rocker.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        this.rocker.on(cc.Node.EventType.TOUCH_END, this.onTouchCancel, this);
    };
    Main.prototype.start = function () {
    };
    Main.prototype.onTouchStart = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
        if (this.touch_distance <= this.rocker_max_r) {
            this.rocker_touched = true;
        }
    };
    Main.prototype.onTouchMove = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
    };
    Main.prototype.onTouchCancel = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.onTouchEnd = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.update = function (dt) {
        if (this.rocker_touched) {
            if (this.touch_distance <= this.rocker_max_r) {
                //摇杆在圈内
                this.rocker_stick.x = this.touch_position.x + this.rocker.x;
                this.rocker_stick.y = this.touch_position.y + this.rocker.y;
            }
            else {
                //摇杆在圈边
                var p = this.touch_position.normalize();
                this.rocker_stick.x = p.x * this.rocker_max_r + this.rocker.x;
                this.rocker_stick.y = p.y * this.rocker_max_r + this.rocker.y;
            }
        }
        this.rocker_x = this.rocker_stick.x - this.rocker.x;
        this.rocker_y = this.rocker_stick.y - this.rocker.y;
        this.player.x += 0.05 * this.rocker_x;
        this.player.y += 0.05 * this.rocker_y;
    };
    __decorate([
        property(cc.Node)
    ], Main.prototype, "player", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker_stick", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHJvY2tlciAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBa0Msd0JBQVk7SUFBOUM7UUFBQSxxRUFtRkM7UUFoRkcsWUFBTSxHQUFZLElBQUksQ0FBQztRQUd2QixZQUFNLEdBQVksSUFBSSxDQUFDO1FBR3ZCLGtCQUFZLEdBQVksSUFBSSxDQUFDO1FBRTdCLG9CQUFvQjtRQUNwQiwwQkFBMEI7UUFFMUIsa0JBQVksR0FBVyxFQUFFLENBQUM7UUFDMUIsb0JBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0Isb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0Isb0JBQWMsR0FBVyxJQUFJLENBQUM7UUFDOUIsY0FBUSxHQUFXLElBQUksQ0FBQztRQUN4QixjQUFRLEdBQVcsSUFBSSxDQUFDOztJQStENUIsQ0FBQztJQTdERyx3QkFBd0I7SUFFeEIscUJBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFRCxvQkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVELDJCQUFZLEdBQVosVUFBYSxDQUFXO1FBQ3BCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ2hELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQzFDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQUVELDBCQUFXLEdBQVgsVUFBWSxDQUFXO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3BELENBQUM7SUFFRCw0QkFBYSxHQUFiLFVBQWMsQ0FBVztRQUNyQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVELHlCQUFVLEdBQVYsVUFBVyxDQUFXO1FBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQscUJBQU0sR0FBTixVQUFPLEVBQVU7UUFDYixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDckIsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQzFDLE9BQU87Z0JBQ1AsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQzVELElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQy9EO2lCQUNJO2dCQUNELE9BQU87Z0JBQ1AsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDakU7U0FDSjtRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBRTtRQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBRTtJQUMzQyxDQUFDO0lBL0VEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7d0NBQ0s7SUFHdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt3Q0FDSztJQUd2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzhDQUNXO0lBVFosSUFBSTtRQUR4QixPQUFPO09BQ2EsSUFBSSxDQW1GeEI7SUFBRCxXQUFDO0NBbkZELEFBbUZDLENBbkZpQyxFQUFFLENBQUMsU0FBUyxHQW1GN0M7a0JBbkZvQixJQUFJIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1haW4gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcGxheWVyOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHJvY2tlcjogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICByb2NrZXJfc3RpY2s6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIC8vIEBwcm9wZXJ0eShudW1iZXIpXHJcbiAgICAvLyBzcGVlZF9jdHJsOiBudW1iZXIgPSAxO1xyXG5cclxuICAgIHJvY2tlcl9tYXhfcjogbnVtYmVyID0gNjA7XHJcbiAgICByb2NrZXJfdG91Y2hlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgdG91Y2hfbG9jYXRpb246IGNjLlZlYzIgPSBudWxsO1xyXG4gICAgdG91Y2hfcG9zaXRpb246IGNjLlZlYzIgPSBudWxsO1xyXG4gICAgdG91Y2hfZGlzdGFuY2U6IG51bWJlciA9IG51bGw7XHJcbiAgICByb2NrZXJfeDogbnVtYmVyID0gbnVsbDtcclxuICAgIHJvY2tlcl95OiBudW1iZXIgPSBudWxsO1xyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICB0aGlzLnJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5vblRvdWNoQ2FuY2VsLCB0aGlzKTtcclxuICAgICAgICB0aGlzLnJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMub25Ub3VjaENhbmNlbCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hTdGFydChlOiBjYy5Ub3VjaCkge1xyXG4gICAgICAgIHRoaXMudG91Y2hfbG9jYXRpb24gPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy50b3VjaF9wb3NpdGlvbiA9IHRoaXMucm9ja2VyLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMudG91Y2hfbG9jYXRpb24pO1xyXG4gICAgICAgIHRoaXMudG91Y2hfZGlzdGFuY2UgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLmxlbigpO1xyXG4gICAgICAgIGlmICh0aGlzLnRvdWNoX2Rpc3RhbmNlIDw9IHRoaXMucm9ja2VyX21heF9yKSB7XHJcbiAgICAgICAgICAgIHRoaXMucm9ja2VyX3RvdWNoZWQgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBvblRvdWNoTW92ZShlOiBjYy5Ub3VjaCkge1xyXG4gICAgICAgIHRoaXMudG91Y2hfbG9jYXRpb24gPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy50b3VjaF9wb3NpdGlvbiA9IHRoaXMucm9ja2VyLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMudG91Y2hfbG9jYXRpb24pO1xyXG4gICAgICAgIHRoaXMudG91Y2hfZGlzdGFuY2UgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLmxlbigpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hDYW5jZWwoZTogY2MuVG91Y2gpIHtcclxuICAgICAgICB0aGlzLnRvdWNoX2xvY2F0aW9uID0gZS5nZXRMb2NhdGlvbigpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyX3RvdWNoZWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnJvY2tlcl9zdGljay5zZXRQb3NpdGlvbih0aGlzLnJvY2tlci5nZXRQb3NpdGlvbigpKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvdWNoRW5kKGU6IGNjLlRvdWNoKSB7XHJcbiAgICAgICAgdGhpcy50b3VjaF9sb2NhdGlvbiA9IGUuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICB0aGlzLnJvY2tlcl90b3VjaGVkID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2suc2V0UG9zaXRpb24odGhpcy5yb2NrZXIuZ2V0UG9zaXRpb24oKSk7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcclxuICAgICAgICBpZiAodGhpcy5yb2NrZXJfdG91Y2hlZCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy50b3VjaF9kaXN0YW5jZSA8PSB0aGlzLnJvY2tlcl9tYXhfcikge1xyXG4gICAgICAgICAgICAgICAgLy/mkYfmnYblnKjlnIjlhoVcclxuICAgICAgICAgICAgICAgIHRoaXMucm9ja2VyX3N0aWNrLnggPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLnggKyB0aGlzLnJvY2tlci54O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2sueSA9IHRoaXMudG91Y2hfcG9zaXRpb24ueSArIHRoaXMucm9ja2VyLnk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL+aRh+adhuWcqOWciOi+uVxyXG4gICAgICAgICAgICAgICAgbGV0IHAgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLm5vcm1hbGl6ZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2sueCA9IHAueCAqIHRoaXMucm9ja2VyX21heF9yICsgdGhpcy5yb2NrZXIueDtcclxuICAgICAgICAgICAgICAgIHRoaXMucm9ja2VyX3N0aWNrLnkgPSBwLnkgKiB0aGlzLnJvY2tlcl9tYXhfciArIHRoaXMucm9ja2VyLnk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMucm9ja2VyX3ggPSB0aGlzLnJvY2tlcl9zdGljay54IC0gdGhpcy5yb2NrZXIueDtcclxuICAgICAgICB0aGlzLnJvY2tlcl95ID0gdGhpcy5yb2NrZXJfc3RpY2sueSAtIHRoaXMucm9ja2VyLnk7XHJcblxyXG4gICAgICAgIHRoaXMucGxheWVyLnggKz0gMC4wNSAqIHRoaXMucm9ja2VyX3ggO1xyXG4gICAgICAgIHRoaXMucGxheWVyLnkgKz0gMC4wNSAqIHRoaXMucm9ja2VyX3kgO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/bullet.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b8094Ib0CVEMZBDniK7KkHz', 'bullet');
// scripts/bullet.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    speed: 800,
    pool: null
  },
  reuse: function reuse(pool) {
    this.pool = pool;
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.pool.put(this.node);
  },
  update: function update(dt) {
    this.node.y += this.speed * dt;

    if (this.node.y > 800) {
      this.pool.put(this.node);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYnVsbGV0LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3BlZWQiLCJwb29sIiwicmV1c2UiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwicHV0Iiwibm9kZSIsInVwZGF0ZSIsImR0IiwieSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBRSxHQURDO0FBRVJDLElBQUFBLElBQUksRUFBRTtBQUZFLEdBSFA7QUFRTEMsRUFBQUEsS0FSSyxpQkFRQ0QsSUFSRCxFQVFPO0FBQ1IsU0FBS0EsSUFBTCxHQUFZQSxJQUFaO0FBQ0gsR0FWSTtBQVlMRSxFQUFBQSxnQkFaSyw0QkFZWUMsS0FaWixFQVltQkMsSUFabkIsRUFZeUI7QUFDMUIsU0FBS0osSUFBTCxDQUFVSyxHQUFWLENBQWMsS0FBS0MsSUFBbkI7QUFDSCxHQWRJO0FBZ0JMQyxFQUFBQSxNQWhCSyxrQkFnQkVDLEVBaEJGLEVBZ0JNO0FBQ1AsU0FBS0YsSUFBTCxDQUFVRyxDQUFWLElBQWUsS0FBS1YsS0FBTCxHQUFhUyxFQUE1Qjs7QUFDQSxRQUFJLEtBQUtGLElBQUwsQ0FBVUcsQ0FBVixHQUFjLEdBQWxCLEVBQXVCO0FBQ25CLFdBQUtULElBQUwsQ0FBVUssR0FBVixDQUFjLEtBQUtDLElBQW5CO0FBQ0g7QUFDSjtBQXJCSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNwZWVkOiA4MDAsXHJcbiAgICAgICAgcG9vbDogbnVsbCxcclxuICAgIH0sXHJcblxyXG4gICAgcmV1c2UocG9vbCkge1xyXG4gICAgICAgIHRoaXMucG9vbCA9IHBvb2w7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXIob3RoZXIsIHNlbGYpIHtcclxuICAgICAgICB0aGlzLnBvb2wucHV0KHRoaXMubm9kZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIHRoaXMubm9kZS55ICs9IHRoaXMuc3BlZWQgKiBkdDtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPiA4MDApIHtcclxuICAgICAgICAgICAgdGhpcy5wb29sLnB1dCh0aGlzLm5vZGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

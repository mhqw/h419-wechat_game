
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/bullet');
require('./assets/scripts/bulletMgr');
require('./assets/scripts/camera_bk');
require('./assets/scripts/ctrl_player');
require('./assets/scripts/ctrl_player_withrocker ');
require('./assets/scripts/ctrl_player_withwasd');
require('./assets/scripts/ctrl_player_withwasd_p2');
require('./assets/scripts/enemy');
require('./assets/scripts/enemyMgr');
require('./assets/scripts/player_hp_mgr');
require('./assets/scripts/preload_choosectrl_scene');
require('./assets/scripts/preload_game_scene');
require('./assets/scripts/preload_game_withro_scene');
require('./assets/scripts/preload_game_withwasd_scene');
require('./assets/scripts/preload_gameover_scene');
require('./assets/scripts/prevent_out');
require('./assets/scripts/test');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/bullet.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b8094Ib0CVEMZBDniK7KkHz', 'bullet');
// scripts/bullet.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    speed: 800,
    pool: null
  },
  reuse: function reuse(pool) {
    this.pool = pool;
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.pool.put(this.node);
  },
  update: function update(dt) {
    this.node.y += this.speed * dt;

    if (this.node.y > 800) {
      this.pool.put(this.node);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYnVsbGV0LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3BlZWQiLCJwb29sIiwicmV1c2UiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwicHV0Iiwibm9kZSIsInVwZGF0ZSIsImR0IiwieSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBRSxHQURDO0FBRVJDLElBQUFBLElBQUksRUFBRTtBQUZFLEdBSFA7QUFRTEMsRUFBQUEsS0FSSyxpQkFRQ0QsSUFSRCxFQVFPO0FBQ1IsU0FBS0EsSUFBTCxHQUFZQSxJQUFaO0FBQ0gsR0FWSTtBQVlMRSxFQUFBQSxnQkFaSyw0QkFZWUMsS0FaWixFQVltQkMsSUFabkIsRUFZeUI7QUFDMUIsU0FBS0osSUFBTCxDQUFVSyxHQUFWLENBQWMsS0FBS0MsSUFBbkI7QUFDSCxHQWRJO0FBZ0JMQyxFQUFBQSxNQWhCSyxrQkFnQkVDLEVBaEJGLEVBZ0JNO0FBQ1AsU0FBS0YsSUFBTCxDQUFVRyxDQUFWLElBQWUsS0FBS1YsS0FBTCxHQUFhUyxFQUE1Qjs7QUFDQSxRQUFJLEtBQUtGLElBQUwsQ0FBVUcsQ0FBVixHQUFjLEdBQWxCLEVBQXVCO0FBQ25CLFdBQUtULElBQUwsQ0FBVUssR0FBVixDQUFjLEtBQUtDLElBQW5CO0FBQ0g7QUFDSjtBQXJCSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNwZWVkOiA4MDAsXHJcbiAgICAgICAgcG9vbDogbnVsbCxcclxuICAgIH0sXHJcblxyXG4gICAgcmV1c2UocG9vbCkge1xyXG4gICAgICAgIHRoaXMucG9vbCA9IHBvb2w7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uQ29sbGlzaW9uRW50ZXIob3RoZXIsIHNlbGYpIHtcclxuICAgICAgICB0aGlzLnBvb2wucHV0KHRoaXMubm9kZSk7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIHRoaXMubm9kZS55ICs9IHRoaXMuc3BlZWQgKiBkdDtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPiA4MDApIHtcclxuICAgICAgICAgICAgdGhpcy5wb29sLnB1dCh0aGlzLm5vZGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/bulletMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5a147DfE6BP1KMMoai9SJjZ', 'bulletMgr');
// scripts/bulletMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    bullet: {
      type: cc.Prefab,
      "default": null
    },
    player: {
      type: cc.Node,
      "default": null
    },
    shootDuration: 0.3
  },
  onLoad: function onLoad() {
    cc.director.getCollisionManager().enabled = true;
    this.pool = new cc.NodePool('bullet');

    for (var i = 0; i < 100; i++) {
      this.pool.put(cc.instantiate(this.bullet));
    }
  },
  start: function start() {
    this.schedule(this.creatManyBullet, this.shootDuration);
  },
  creatManyBullet: function creatManyBullet() {
    var px = this.player.x;
    var py = this.player.y;
    var offset = 55;
    this.creatOneBullet(px, py);
    this.creatOneBullet(px - offset, py);
    this.creatOneBullet(px + offset, py);
  },
  creatOneBullet: function creatOneBullet(x, y) {
    var b = this.pool.get(this.pool);
    if (!b) b = cc.instantiate(this.bullet);
    b.parent = this.node;
    b.x = x;
    b.y = y + 50;
  } //update(dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYnVsbGV0TWdyLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYnVsbGV0IiwidHlwZSIsIlByZWZhYiIsInBsYXllciIsIk5vZGUiLCJzaG9vdER1cmF0aW9uIiwib25Mb2FkIiwiZGlyZWN0b3IiLCJnZXRDb2xsaXNpb25NYW5hZ2VyIiwiZW5hYmxlZCIsInBvb2wiLCJOb2RlUG9vbCIsImkiLCJwdXQiLCJpbnN0YW50aWF0ZSIsInN0YXJ0Iiwic2NoZWR1bGUiLCJjcmVhdE1hbnlCdWxsZXQiLCJweCIsIngiLCJweSIsInkiLCJvZmZzZXQiLCJjcmVhdE9uZUJ1bGxldCIsImIiLCJnZXQiLCJwYXJlbnQiLCJub2RlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFFO0FBQ0pDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQURMO0FBRUosaUJBQVM7QUFGTCxLQURBO0FBS1JDLElBQUFBLE1BQU0sRUFBRTtBQUNKRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1EsSUFETDtBQUVKLGlCQUFTO0FBRkwsS0FMQTtBQVNSQyxJQUFBQSxhQUFhLEVBQUU7QUFUUCxHQUhQO0FBZUxDLEVBQUFBLE1BZkssb0JBZUk7QUFDTFYsSUFBQUEsRUFBRSxDQUFDVyxRQUFILENBQVlDLG1CQUFaLEdBQWtDQyxPQUFsQyxHQUE0QyxJQUE1QztBQUNBLFNBQUtDLElBQUwsR0FBWSxJQUFJZCxFQUFFLENBQUNlLFFBQVAsQ0FBZ0IsUUFBaEIsQ0FBWjs7QUFDQSxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsR0FBcEIsRUFBeUJBLENBQUMsRUFBMUIsRUFBOEI7QUFDMUIsV0FBS0YsSUFBTCxDQUFVRyxHQUFWLENBQWNqQixFQUFFLENBQUNrQixXQUFILENBQWUsS0FBS2QsTUFBcEIsQ0FBZDtBQUNIO0FBQ0osR0FyQkk7QUF1QkxlLEVBQUFBLEtBdkJLLG1CQXVCRztBQUNKLFNBQUtDLFFBQUwsQ0FBYyxLQUFLQyxlQUFuQixFQUFvQyxLQUFLWixhQUF6QztBQUNILEdBekJJO0FBMkJMWSxFQUFBQSxlQTNCSyw2QkEyQmE7QUFDZCxRQUFJQyxFQUFFLEdBQUcsS0FBS2YsTUFBTCxDQUFZZ0IsQ0FBckI7QUFDQSxRQUFJQyxFQUFFLEdBQUcsS0FBS2pCLE1BQUwsQ0FBWWtCLENBQXJCO0FBQ0EsUUFBSUMsTUFBTSxHQUFHLEVBQWI7QUFDQSxTQUFLQyxjQUFMLENBQW9CTCxFQUFwQixFQUF3QkUsRUFBeEI7QUFDQSxTQUFLRyxjQUFMLENBQW9CTCxFQUFFLEdBQUdJLE1BQXpCLEVBQWlDRixFQUFqQztBQUNBLFNBQUtHLGNBQUwsQ0FBb0JMLEVBQUUsR0FBR0ksTUFBekIsRUFBaUNGLEVBQWpDO0FBQ0gsR0FsQ0k7QUFvQ0xHLEVBQUFBLGNBcENLLDBCQW9DVUosQ0FwQ1YsRUFvQ2FFLENBcENiLEVBb0NnQjtBQUNqQixRQUFJRyxDQUFDLEdBQUcsS0FBS2QsSUFBTCxDQUFVZSxHQUFWLENBQWMsS0FBS2YsSUFBbkIsQ0FBUjtBQUNBLFFBQUksQ0FBQ2MsQ0FBTCxFQUNJQSxDQUFDLEdBQUc1QixFQUFFLENBQUNrQixXQUFILENBQWUsS0FBS2QsTUFBcEIsQ0FBSjtBQUNKd0IsSUFBQUEsQ0FBQyxDQUFDRSxNQUFGLEdBQVcsS0FBS0MsSUFBaEI7QUFDQUgsSUFBQUEsQ0FBQyxDQUFDTCxDQUFGLEdBQU1BLENBQU47QUFDQUssSUFBQUEsQ0FBQyxDQUFDSCxDQUFGLEdBQU1BLENBQUMsR0FBRyxFQUFWO0FBQ0gsR0EzQ0ksQ0E4Q0w7O0FBOUNLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgYnVsbGV0OiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHBsYXllcjoge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2hvb3REdXJhdGlvbjogMC4zLFxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IuZ2V0Q29sbGlzaW9uTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMucG9vbCA9IG5ldyBjYy5Ob2RlUG9vbCgnYnVsbGV0Jyk7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDA7IGkrKykge1xyXG4gICAgICAgICAgICB0aGlzLnBvb2wucHV0KGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0KSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuY3JlYXRNYW55QnVsbGV0LCB0aGlzLnNob290RHVyYXRpb24pO1xyXG4gICAgfSxcclxuXHJcbiAgICBjcmVhdE1hbnlCdWxsZXQoKSB7XHJcbiAgICAgICAgbGV0IHB4ID0gdGhpcy5wbGF5ZXIueDtcclxuICAgICAgICBsZXQgcHkgPSB0aGlzLnBsYXllci55O1xyXG4gICAgICAgIGxldCBvZmZzZXQgPSA1NTtcclxuICAgICAgICB0aGlzLmNyZWF0T25lQnVsbGV0KHB4LCBweSk7XHJcbiAgICAgICAgdGhpcy5jcmVhdE9uZUJ1bGxldChweCAtIG9mZnNldCwgcHkpO1xyXG4gICAgICAgIHRoaXMuY3JlYXRPbmVCdWxsZXQocHggKyBvZmZzZXQsIHB5KTtcclxuICAgIH0sXHJcblxyXG4gICAgY3JlYXRPbmVCdWxsZXQoeCwgeSkge1xyXG4gICAgICAgIGxldCBiID0gdGhpcy5wb29sLmdldCh0aGlzLnBvb2wpO1xyXG4gICAgICAgIGlmICghYilcclxuICAgICAgICAgICAgYiA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVsbGV0KTtcclxuICAgICAgICBiLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICBiLnggPSB4O1xyXG4gICAgICAgIGIueSA9IHkgKyA1MDtcclxuICAgIH0sXHJcblxyXG5cclxuICAgIC8vdXBkYXRlKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
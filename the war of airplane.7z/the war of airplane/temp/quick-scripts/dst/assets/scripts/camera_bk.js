
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/camera_bk.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd958dgWyJRNG5iVSuSy+uNo', 'camera_bk');
// scripts/camera_bk.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // onLoad () {},
  start: function start() {
    var _this = this;

    cc.tween(this.node).repeatForever(cc.tween().to(10, {
      position: cc.v2(0, 1440)
    }).call(function () {
      _this.node.y = 0;
    })).start();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY2FtZXJhX2JrLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwic3RhcnQiLCJ0d2VlbiIsIm5vZGUiLCJyZXBlYXRGb3JldmVyIiwidG8iLCJwb3NpdGlvbiIsInYyIiwiY2FsbCIsInkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsS0FUSyxtQkFTSTtBQUFBOztBQUNMSixJQUFBQSxFQUFFLENBQUNLLEtBQUgsQ0FBUyxLQUFLQyxJQUFkLEVBQ0tDLGFBREwsQ0FFUVAsRUFBRSxDQUFDSyxLQUFILEdBQ0tHLEVBREwsQ0FDUSxFQURSLEVBQ1c7QUFBQ0MsTUFBQUEsUUFBUSxFQUFFVCxFQUFFLENBQUNVLEVBQUgsQ0FBTSxDQUFOLEVBQVEsSUFBUjtBQUFYLEtBRFgsRUFFS0MsSUFGTCxDQUVVLFlBQUk7QUFBQyxNQUFBLEtBQUksQ0FBQ0wsSUFBTCxDQUFVTSxDQUFWLEdBQWMsQ0FBZDtBQUFnQixLQUYvQixDQUZSLEVBS01SLEtBTE47QUFNSCxHQWhCSSxDQWtCTDs7QUFsQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBcclxuICAgIH0sXHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBjYy50d2Vlbih0aGlzLm5vZGUpXHJcbiAgICAgICAgICAgIC5yZXBlYXRGb3JldmVyKFxyXG4gICAgICAgICAgICAgICAgY2MudHdlZW4oKVxyXG4gICAgICAgICAgICAgICAgICAgIC50bygxMCx7cG9zaXRpb246IGNjLnYyKDAsMTQ0MCl9KVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYWxsKCgpPT57dGhpcy5ub2RlLnkgPSAwfSlcclxuICAgICAgICAgICAgKS5zdGFydCgpO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
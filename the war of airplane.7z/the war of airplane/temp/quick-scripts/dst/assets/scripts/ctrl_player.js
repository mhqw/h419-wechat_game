
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd0f17Uy0qRN6o7NUeQlamc0', 'ctrl_player');
// scripts/ctrl_player.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onTouchStart: function onTouchStart(t) {},
  onTouchMove: function onTouchMove(t) {
    var delta = t.getDelta();
    this.node.x += delta.x;
    this.node.y += delta.y;
  },
  onTouchEnd: function onTouchEnd(t) {},
  start: function start() {
    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
  },
  update: function update(dt) {
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvblRvdWNoU3RhcnQiLCJ0Iiwib25Ub3VjaE1vdmUiLCJkZWx0YSIsImdldERlbHRhIiwibm9kZSIsIngiLCJ5Iiwib25Ub3VjaEVuZCIsInN0YXJ0Iiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfU1RBUlQiLCJUT1VDSF9NT1ZFIiwiVE9VQ0hfRU5EIiwidXBkYXRlIiwiZHQiLCJ3aW5TaXplIiwid2lkdGgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxDQUNSO0FBQ0E7QUFDQTtBQUNBO0FBSlEsR0FIUDtBQVVMO0FBRUE7QUFFQUMsRUFBQUEsWUFkSyx3QkFjUUMsQ0FkUixFQWNXLENBRWYsQ0FoQkk7QUFrQkxDLEVBQUFBLFdBbEJLLHVCQWtCT0QsQ0FsQlAsRUFrQlU7QUFDWCxRQUFJRSxLQUFLLEdBQUdGLENBQUMsQ0FBQ0csUUFBRixFQUFaO0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxDQUFWLElBQWVILEtBQUssQ0FBQ0csQ0FBckI7QUFDQSxTQUFLRCxJQUFMLENBQVVFLENBQVYsSUFBZUosS0FBSyxDQUFDSSxDQUFyQjtBQUNILEdBdEJJO0FBd0JMQyxFQUFBQSxVQXhCSyxzQkF3Qk1QLENBeEJOLEVBd0JTLENBRWIsQ0ExQkk7QUE0QkxRLEVBQUFBLEtBNUJLLG1CQTRCRztBQUNKLFNBQUtKLElBQUwsQ0FBVUssRUFBVixDQUFhZCxFQUFFLENBQUNlLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBL0IsRUFBNEMsS0FBS2IsWUFBakQsRUFBK0QsSUFBL0Q7QUFDQSxTQUFLSyxJQUFMLENBQVVLLEVBQVYsQ0FBYWQsRUFBRSxDQUFDZSxJQUFILENBQVFDLFNBQVIsQ0FBa0JFLFVBQS9CLEVBQTJDLEtBQUtaLFdBQWhELEVBQTZELElBQTdEO0FBQ0EsU0FBS0csSUFBTCxDQUFVSyxFQUFWLENBQWFkLEVBQUUsQ0FBQ2UsSUFBSCxDQUFRQyxTQUFSLENBQWtCRyxTQUEvQixFQUEwQyxLQUFLUCxVQUEvQyxFQUEyRCxJQUEzRDtBQUNILEdBaENJO0FBa0NMUSxFQUFBQSxNQWxDSyxrQkFrQ0VDLEVBbENGLEVBa0NNO0FBQ1AsUUFBSSxLQUFLWixJQUFMLENBQVVDLENBQVYsSUFBZVYsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUE1RCxFQUErRDtBQUMzRCxXQUFLZCxJQUFMLENBQVVDLENBQVYsR0FBY1YsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUF2RDtBQUNIOztBQUNELFFBQUksS0FBS2QsSUFBTCxDQUFVQyxDQUFWLElBQWUsQ0FBQ1YsRUFBRSxDQUFDc0IsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtkLElBQUwsQ0FBVWMsS0FBVixHQUFrQixDQUE3RCxFQUFnRTtBQUM1RCxXQUFLZCxJQUFMLENBQVVDLENBQVYsR0FBYyxDQUFDVixFQUFFLENBQUNzQixPQUFILENBQVdDLEtBQVosR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS2QsSUFBTCxDQUFVYyxLQUFWLEdBQWtCLENBQXhEO0FBQ0g7QUFDSjtBQXpDSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIHBsYXllcjp7XHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgb25Ub3VjaFN0YXJ0KHQpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uVG91Y2hNb3ZlKHQpIHtcclxuICAgICAgICB2YXIgZGVsdGEgPSB0LmdldERlbHRhKCk7XHJcbiAgICAgICAgdGhpcy5ub2RlLnggKz0gZGVsdGEueDtcclxuICAgICAgICB0aGlzLm5vZGUueSArPSBkZWx0YS55O1xyXG4gICAgfSxcclxuXHJcbiAgICBvblRvdWNoRW5kKHQpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpO1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPj0gY2Mud2luU2l6ZS53aWR0aCAvIDIgLSB0aGlzLm5vZGUud2lkdGggLyAyKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS54ID0gY2Mud2luU2l6ZS53aWR0aCAvIDIgLSB0aGlzLm5vZGUud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPD0gLWNjLndpblNpemUud2lkdGggLyAyICsgdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IC1jYy53aW5TaXplLndpZHRoIC8gMiArIHRoaXMubm9kZS53aWR0aCAvIDI7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxufSk7XHJcbiJdfQ==
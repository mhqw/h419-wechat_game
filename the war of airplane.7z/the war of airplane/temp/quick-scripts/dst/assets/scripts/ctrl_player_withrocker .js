
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withrocker .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b38acFBUl5MdY2DzGXp3MXp', 'ctrl_player_withrocker ');
// scripts/ctrl_player_withrocker .ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.rocker = null;
        _this.rocker_stick = null;
        // @property(number)
        // speed_ctrl: number = 1;
        _this.rocker_max_r = 60;
        _this.rocker_touched = false;
        _this.touch_location = null;
        _this.touch_position = null;
        _this.touch_distance = null;
        _this.rocker_x = null;
        _this.rocker_y = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    Main.prototype.onLoad = function () {
        this.rocker.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.rocker.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.rocker.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        this.rocker.on(cc.Node.EventType.TOUCH_END, this.onTouchCancel, this);
    };
    Main.prototype.start = function () {
    };
    Main.prototype.onTouchStart = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
        if (this.touch_distance <= this.rocker_max_r) {
            this.rocker_touched = true;
        }
    };
    Main.prototype.onTouchMove = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
    };
    Main.prototype.onTouchCancel = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.onTouchEnd = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.update = function (dt) {
        if (this.rocker_touched) {
            if (this.touch_distance <= this.rocker_max_r) {
                //摇杆在圈内
                this.rocker_stick.x = this.touch_position.x + this.rocker.x;
                this.rocker_stick.y = this.touch_position.y + this.rocker.y;
            }
            else {
                //摇杆在圈边
                var p = this.touch_position.normalize();
                this.rocker_stick.x = p.x * this.rocker_max_r + this.rocker.x;
                this.rocker_stick.y = p.y * this.rocker_max_r + this.rocker.y;
            }
        }
        this.rocker_x = this.rocker_stick.x - this.rocker.x;
        this.rocker_y = this.rocker_stick.y - this.rocker.y;
        this.player.x += 0.05 * this.rocker_x;
        this.player.y += 0.05 * this.rocker_y;
    };
    __decorate([
        property(cc.Node)
    ], Main.prototype, "player", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker_stick", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHJvY2tlciAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBa0Msd0JBQVk7SUFBOUM7UUFBQSxxRUFtRkM7UUFoRkcsWUFBTSxHQUFZLElBQUksQ0FBQztRQUd2QixZQUFNLEdBQVksSUFBSSxDQUFDO1FBR3ZCLGtCQUFZLEdBQVksSUFBSSxDQUFDO1FBRTdCLG9CQUFvQjtRQUNwQiwwQkFBMEI7UUFFMUIsa0JBQVksR0FBVyxFQUFFLENBQUM7UUFDMUIsb0JBQWMsR0FBWSxLQUFLLENBQUM7UUFDaEMsb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0Isb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFDL0Isb0JBQWMsR0FBVyxJQUFJLENBQUM7UUFDOUIsY0FBUSxHQUFXLElBQUksQ0FBQztRQUN4QixjQUFRLEdBQVcsSUFBSSxDQUFDOztJQStENUIsQ0FBQztJQTdERyx3QkFBd0I7SUFFeEIscUJBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3pFLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFFLENBQUM7SUFFRCxvQkFBSyxHQUFMO0lBRUEsQ0FBQztJQUVELDJCQUFZLEdBQVosVUFBYSxDQUFXO1FBQ3BCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ2hELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQzFDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1NBQzlCO0lBQ0wsQ0FBQztJQUVELDBCQUFXLEdBQVgsVUFBWSxDQUFXO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDO0lBQ3BELENBQUM7SUFFRCw0QkFBYSxHQUFiLFVBQWMsQ0FBVztRQUNyQixJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN0QyxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVELHlCQUFVLEdBQVYsVUFBVyxDQUFXO1FBQ2xCLElBQUksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3RDLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1FBQzVCLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRUQscUJBQU0sR0FBTixVQUFPLEVBQVU7UUFDYixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDckIsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQzFDLE9BQU87Z0JBQ1AsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQzVELElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQy9EO2lCQUNJO2dCQUNELE9BQU87Z0JBQ1AsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDakU7U0FDSjtRQUVELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBRTtRQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBRTtJQUMzQyxDQUFDO0lBL0VEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7d0NBQ0s7SUFHdkI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzt3Q0FDSztJQUd2QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzhDQUNXO0lBVFosSUFBSTtRQUR4QixPQUFPO09BQ2EsSUFBSSxDQW1GeEI7SUFBRCxXQUFDO0NBbkZELEFBbUZDLENBbkZpQyxFQUFFLENBQUMsU0FBUyxHQW1GN0M7a0JBbkZvQixJQUFJIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1haW4gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgcGxheWVyOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHJvY2tlcjogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICByb2NrZXJfc3RpY2s6IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIC8vIEBwcm9wZXJ0eShudW1iZXIpXHJcbiAgICAvLyBzcGVlZF9jdHJsOiBudW1iZXIgPSAxO1xyXG5cclxuICAgIHJvY2tlcl9tYXhfcjogbnVtYmVyID0gNjA7XHJcbiAgICByb2NrZXJfdG91Y2hlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgdG91Y2hfbG9jYXRpb246IGNjLlZlYzIgPSBudWxsO1xyXG4gICAgdG91Y2hfcG9zaXRpb246IGNjLlZlYzIgPSBudWxsO1xyXG4gICAgdG91Y2hfZGlzdGFuY2U6IG51bWJlciA9IG51bGw7XHJcbiAgICByb2NrZXJfeDogbnVtYmVyID0gbnVsbDtcclxuICAgIHJvY2tlcl95OiBudW1iZXIgPSBudWxsO1xyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICB0aGlzLnJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5vblRvdWNoQ2FuY2VsLCB0aGlzKTtcclxuICAgICAgICB0aGlzLnJvY2tlci5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMub25Ub3VjaENhbmNlbCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgc3RhcnQoKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hTdGFydChlOiBjYy5Ub3VjaCkge1xyXG4gICAgICAgIHRoaXMudG91Y2hfbG9jYXRpb24gPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy50b3VjaF9wb3NpdGlvbiA9IHRoaXMucm9ja2VyLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMudG91Y2hfbG9jYXRpb24pO1xyXG4gICAgICAgIHRoaXMudG91Y2hfZGlzdGFuY2UgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLmxlbigpO1xyXG4gICAgICAgIGlmICh0aGlzLnRvdWNoX2Rpc3RhbmNlIDw9IHRoaXMucm9ja2VyX21heF9yKSB7XHJcbiAgICAgICAgICAgIHRoaXMucm9ja2VyX3RvdWNoZWQgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBvblRvdWNoTW92ZShlOiBjYy5Ub3VjaCkge1xyXG4gICAgICAgIHRoaXMudG91Y2hfbG9jYXRpb24gPSBlLmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgdGhpcy50b3VjaF9wb3NpdGlvbiA9IHRoaXMucm9ja2VyLmNvbnZlcnRUb05vZGVTcGFjZUFSKHRoaXMudG91Y2hfbG9jYXRpb24pO1xyXG4gICAgICAgIHRoaXMudG91Y2hfZGlzdGFuY2UgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLmxlbigpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hDYW5jZWwoZTogY2MuVG91Y2gpIHtcclxuICAgICAgICB0aGlzLnRvdWNoX2xvY2F0aW9uID0gZS5nZXRMb2NhdGlvbigpO1xyXG4gICAgICAgIHRoaXMucm9ja2VyX3RvdWNoZWQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnJvY2tlcl9zdGljay5zZXRQb3NpdGlvbih0aGlzLnJvY2tlci5nZXRQb3NpdGlvbigpKTtcclxuICAgIH1cclxuXHJcbiAgICBvblRvdWNoRW5kKGU6IGNjLlRvdWNoKSB7XHJcbiAgICAgICAgdGhpcy50b3VjaF9sb2NhdGlvbiA9IGUuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICB0aGlzLnJvY2tlcl90b3VjaGVkID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2suc2V0UG9zaXRpb24odGhpcy5yb2NrZXIuZ2V0UG9zaXRpb24oKSk7XHJcbiAgICB9XHJcblxyXG4gICAgdXBkYXRlKGR0OiBudW1iZXIpIHtcclxuICAgICAgICBpZiAodGhpcy5yb2NrZXJfdG91Y2hlZCkge1xyXG4gICAgICAgICAgICBpZiAodGhpcy50b3VjaF9kaXN0YW5jZSA8PSB0aGlzLnJvY2tlcl9tYXhfcikge1xyXG4gICAgICAgICAgICAgICAgLy/mkYfmnYblnKjlnIjlhoVcclxuICAgICAgICAgICAgICAgIHRoaXMucm9ja2VyX3N0aWNrLnggPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLnggKyB0aGlzLnJvY2tlci54O1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2sueSA9IHRoaXMudG91Y2hfcG9zaXRpb24ueSArIHRoaXMucm9ja2VyLnk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAvL+aRh+adhuWcqOWciOi+uVxyXG4gICAgICAgICAgICAgICAgbGV0IHAgPSB0aGlzLnRvdWNoX3Bvc2l0aW9uLm5vcm1hbGl6ZSgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb2NrZXJfc3RpY2sueCA9IHAueCAqIHRoaXMucm9ja2VyX21heF9yICsgdGhpcy5yb2NrZXIueDtcclxuICAgICAgICAgICAgICAgIHRoaXMucm9ja2VyX3N0aWNrLnkgPSBwLnkgKiB0aGlzLnJvY2tlcl9tYXhfciArIHRoaXMucm9ja2VyLnk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMucm9ja2VyX3ggPSB0aGlzLnJvY2tlcl9zdGljay54IC0gdGhpcy5yb2NrZXIueDtcclxuICAgICAgICB0aGlzLnJvY2tlcl95ID0gdGhpcy5yb2NrZXJfc3RpY2sueSAtIHRoaXMucm9ja2VyLnk7XHJcblxyXG4gICAgICAgIHRoaXMucGxheWVyLnggKz0gMC4wNSAqIHRoaXMucm9ja2VyX3ggO1xyXG4gICAgICAgIHRoaXMucGxheWVyLnkgKz0gMC4wNSAqIHRoaXMucm9ja2VyX3kgO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
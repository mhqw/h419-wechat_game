
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withwasd.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e6a33WfoxlKsYgiNxLO4bUu', 'ctrl_player_withwasd');
// scripts/ctrl_player_withwasd.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    dir: {
      type: require("ctrl_player_withwasd_p2"),
      "default": null
    },
    maxSpeed: 0,
    accle: 0
  },
  start: function start() {
    this.xSpeed = 0;
    this.ySpeed = 0;
  },
  update: function update(dt) {
    if (this.dir.onLeft) {
      this.xSpeed -= this.accle * dt;
    } else if (this.dir.onRight) {
      this.xSpeed += this.accle * dt;
    } else {
      this.xSpeed = 0;
    }

    if (this.dir.onDown) {
      this.ySpeed -= this.accle * dt;
    } else if (this.dir.onUp) {
      this.ySpeed += this.accle * dt;
    } else {
      this.ySpeed = 0;
    }

    if (Math.abs(this.xSpeed) > this.maxSpeed) {
      this.xSpeed = this.maxSpeed * this.xSpeed / Math.abs(this.xSpeed);
    }

    if (Math.abs(this.ySpeed) > this.maxSpeed) {
      this.ySpeed = this.maxSpeed * this.ySpeed / Math.abs(this.ySpeed);
    }

    this.node.x += this.xSpeed * dt;
    this.node.y += this.ySpeed * dt;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHdhc2QuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJkaXIiLCJ0eXBlIiwicmVxdWlyZSIsIm1heFNwZWVkIiwiYWNjbGUiLCJzdGFydCIsInhTcGVlZCIsInlTcGVlZCIsInVwZGF0ZSIsImR0Iiwib25MZWZ0Iiwib25SaWdodCIsIm9uRG93biIsIm9uVXAiLCJNYXRoIiwiYWJzIiwibm9kZSIsIngiLCJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsR0FBRyxFQUFFO0FBQ0RDLE1BQUFBLElBQUksRUFBRUMsT0FBTyxDQUFDLHlCQUFELENBRFo7QUFFRCxpQkFBUztBQUZSLEtBREc7QUFNUkMsSUFBQUEsUUFBUSxFQUFFLENBTkY7QUFPUkMsSUFBQUEsS0FBSyxFQUFFO0FBUEMsR0FIUDtBQWFMQyxFQUFBQSxLQWJLLG1CQWFHO0FBQ0osU0FBS0MsTUFBTCxHQUFjLENBQWQ7QUFDQSxTQUFLQyxNQUFMLEdBQWMsQ0FBZDtBQUNILEdBaEJJO0FBa0JMQyxFQUFBQSxNQWxCSyxrQkFrQkVDLEVBbEJGLEVBa0JNO0FBQ1AsUUFBSSxLQUFLVCxHQUFMLENBQVNVLE1BQWIsRUFBcUI7QUFDakIsV0FBS0osTUFBTCxJQUFlLEtBQUtGLEtBQUwsR0FBYUssRUFBNUI7QUFDSCxLQUZELE1BR0ssSUFBSSxLQUFLVCxHQUFMLENBQVNXLE9BQWIsRUFBc0I7QUFDdkIsV0FBS0wsTUFBTCxJQUFlLEtBQUtGLEtBQUwsR0FBYUssRUFBNUI7QUFDSCxLQUZJLE1BR0E7QUFDRCxXQUFLSCxNQUFMLEdBQWMsQ0FBZDtBQUNIOztBQUNELFFBQUksS0FBS04sR0FBTCxDQUFTWSxNQUFiLEVBQXFCO0FBQ2pCLFdBQUtMLE1BQUwsSUFBZSxLQUFLSCxLQUFMLEdBQWFLLEVBQTVCO0FBQ0gsS0FGRCxNQUdLLElBQUksS0FBS1QsR0FBTCxDQUFTYSxJQUFiLEVBQW1CO0FBQ3BCLFdBQUtOLE1BQUwsSUFBZSxLQUFLSCxLQUFMLEdBQWFLLEVBQTVCO0FBQ0gsS0FGSSxNQUdBO0FBQ0QsV0FBS0YsTUFBTCxHQUFjLENBQWQ7QUFDSDs7QUFFRCxRQUFJTyxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLVCxNQUFkLElBQXdCLEtBQUtILFFBQWpDLEVBQTJDO0FBQ3ZDLFdBQUtHLE1BQUwsR0FBYyxLQUFLSCxRQUFMLEdBQWdCLEtBQUtHLE1BQXJCLEdBQThCUSxJQUFJLENBQUNDLEdBQUwsQ0FBUyxLQUFLVCxNQUFkLENBQTVDO0FBQ0g7O0FBQ0QsUUFBSVEsSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1IsTUFBZCxJQUF3QixLQUFLSixRQUFqQyxFQUEyQztBQUN2QyxXQUFLSSxNQUFMLEdBQWMsS0FBS0osUUFBTCxHQUFnQixLQUFLSSxNQUFyQixHQUE4Qk8sSUFBSSxDQUFDQyxHQUFMLENBQVMsS0FBS1IsTUFBZCxDQUE1QztBQUNIOztBQUVELFNBQUtTLElBQUwsQ0FBVUMsQ0FBVixJQUFlLEtBQUtYLE1BQUwsR0FBY0csRUFBN0I7QUFDQSxTQUFLTyxJQUFMLENBQVVFLENBQVYsSUFBZSxLQUFLWCxNQUFMLEdBQWNFLEVBQTdCO0FBQ0g7QUEvQ0ksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBkaXI6IHtcclxuICAgICAgICAgICAgdHlwZTogcmVxdWlyZShcImN0cmxfcGxheWVyX3dpdGh3YXNkX3AyXCIpLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIG1heFNwZWVkOiAwLFxyXG4gICAgICAgIGFjY2xlOiAwLFxyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnhTcGVlZCA9IDA7XHJcbiAgICAgICAgdGhpcy55U3BlZWQgPSAwO1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5kaXIub25MZWZ0KSB7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkIC09IHRoaXMuYWNjbGUgKiBkdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAodGhpcy5kaXIub25SaWdodCkge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCArPSB0aGlzLmFjY2xlICogZHQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLnhTcGVlZCA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICh0aGlzLmRpci5vbkRvd24pIHtcclxuICAgICAgICAgICAgdGhpcy55U3BlZWQgLT0gdGhpcy5hY2NsZSAqIGR0O1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmICh0aGlzLmRpci5vblVwKSB7XHJcbiAgICAgICAgICAgIHRoaXMueVNwZWVkICs9IHRoaXMuYWNjbGUgKiBkdDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMueVNwZWVkID0gMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChNYXRoLmFicyh0aGlzLnhTcGVlZCkgPiB0aGlzLm1heFNwZWVkKSB7XHJcbiAgICAgICAgICAgIHRoaXMueFNwZWVkID0gdGhpcy5tYXhTcGVlZCAqIHRoaXMueFNwZWVkIC8gTWF0aC5hYnModGhpcy54U3BlZWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoTWF0aC5hYnModGhpcy55U3BlZWQpID4gdGhpcy5tYXhTcGVlZCkge1xyXG4gICAgICAgICAgICB0aGlzLnlTcGVlZCA9IHRoaXMubWF4U3BlZWQgKiB0aGlzLnlTcGVlZCAvIE1hdGguYWJzKHRoaXMueVNwZWVkKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubm9kZS54ICs9IHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgKz0gdGhpcy55U3BlZWQgKiBkdDtcclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
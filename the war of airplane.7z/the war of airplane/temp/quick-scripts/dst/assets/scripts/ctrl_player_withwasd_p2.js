
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ctrl_player_withwasd_p2.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e7fabmMsQFPCKrq+7KgKuXb', 'ctrl_player_withwasd_p2');
// scripts/ctrl_player_withwasd_p2.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    left: {
      type: cc.Node,
      "default": null
    },
    right: {
      type: cc.Node,
      "default": null
    },
    up: {
      type: cc.Node,
      "default": null
    },
    down: {
      type: cc.Node,
      "default": null
    }
  },
  onLeftStart: function onLeftStart() {
    this.onLeft = true;
  },
  onLeftEnd: function onLeftEnd() {
    this.onLeft = false;
  },
  onRightStart: function onRightStart() {
    this.onRight = true;
  },
  onRightEnd: function onRightEnd() {
    this.onRight = false;
  },
  onUpStart: function onUpStart() {
    this.onUp = true;
  },
  onUpEnd: function onUpEnd() {
    this.onUp = false;
  },
  onDownStart: function onDownStart() {
    this.onDown = true;
  },
  onDownEnd: function onDownEnd() {
    this.onDown = false;
  },
  start: function start() {
    this.onLeft = false;
    this.onRight = false;
    this.onUp = false;
    this.onDown = false;
    this.left.on(cc.Node.EventType.TOUCH_START, this.onLeftStart, this);
    this.left.on(cc.Node.EventType.TOUCH_END, this.onLeftEnd, this);
    this.right.on(cc.Node.EventType.TOUCH_START, this.onRightStart, this);
    this.right.on(cc.Node.EventType.TOUCH_END, this.onRightEnd, this);
    this.up.on(cc.Node.EventType.TOUCH_START, this.onUpStart, this);
    this.up.on(cc.Node.EventType.TOUCH_END, this.onUpEnd, this);
    this.down.on(cc.Node.EventType.TOUCH_START, this.onDownStart, this);
    this.down.on(cc.Node.EventType.TOUCH_END, this.onDownEnd, this);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcY3RybF9wbGF5ZXJfd2l0aHdhc2RfcDIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJsZWZ0IiwidHlwZSIsIk5vZGUiLCJyaWdodCIsInVwIiwiZG93biIsIm9uTGVmdFN0YXJ0Iiwib25MZWZ0Iiwib25MZWZ0RW5kIiwib25SaWdodFN0YXJ0Iiwib25SaWdodCIsIm9uUmlnaHRFbmQiLCJvblVwU3RhcnQiLCJvblVwIiwib25VcEVuZCIsIm9uRG93blN0YXJ0Iiwib25Eb3duIiwib25Eb3duRW5kIiwic3RhcnQiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiVE9VQ0hfRU5EIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0ZDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURQO0FBRUYsaUJBQVM7QUFGUCxLQURFO0FBS1JDLElBQUFBLEtBQUssRUFBRTtBQUNIRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sSUFETjtBQUVILGlCQUFTO0FBRk4sS0FMQztBQVNSRSxJQUFBQSxFQUFFLEVBQUM7QUFDQ0gsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBRFY7QUFFQyxpQkFBUztBQUZWLEtBVEs7QUFhUkcsSUFBQUEsSUFBSSxFQUFDO0FBQ0RKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQURSO0FBRUQsaUJBQVM7QUFGUjtBQWJHLEdBSFA7QUFzQkxJLEVBQUFBLFdBdEJLLHlCQXNCUTtBQUNULFNBQUtDLE1BQUwsR0FBYyxJQUFkO0FBQ0gsR0F4Qkk7QUEwQkxDLEVBQUFBLFNBMUJLLHVCQTBCTTtBQUNQLFNBQUtELE1BQUwsR0FBYyxLQUFkO0FBQ0gsR0E1Qkk7QUE4QkxFLEVBQUFBLFlBOUJLLDBCQThCUztBQUNWLFNBQUtDLE9BQUwsR0FBZSxJQUFmO0FBQ0gsR0FoQ0k7QUFrQ0xDLEVBQUFBLFVBbENLLHdCQWtDTztBQUNSLFNBQUtELE9BQUwsR0FBZSxLQUFmO0FBQ0gsR0FwQ0k7QUFzQ0xFLEVBQUFBLFNBdENLLHVCQXNDTTtBQUNQLFNBQUtDLElBQUwsR0FBWSxJQUFaO0FBQ0gsR0F4Q0k7QUEwQ0xDLEVBQUFBLE9BMUNLLHFCQTBDSTtBQUNMLFNBQUtELElBQUwsR0FBWSxLQUFaO0FBQ0gsR0E1Q0k7QUE4Q0xFLEVBQUFBLFdBOUNLLHlCQThDUTtBQUNULFNBQUtDLE1BQUwsR0FBYyxJQUFkO0FBQ0gsR0FoREk7QUFrRExDLEVBQUFBLFNBbERLLHVCQWtETTtBQUNQLFNBQUtELE1BQUwsR0FBYyxLQUFkO0FBQ0gsR0FwREk7QUFzRExFLEVBQUFBLEtBdERLLG1CQXNESTtBQUNMLFNBQUtYLE1BQUwsR0FBYyxLQUFkO0FBQ0EsU0FBS0csT0FBTCxHQUFlLEtBQWY7QUFDQSxTQUFLRyxJQUFMLEdBQVksS0FBWjtBQUNBLFNBQUtHLE1BQUwsR0FBYyxLQUFkO0FBRUEsU0FBS2hCLElBQUwsQ0FBVW1CLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBL0IsRUFBMkMsS0FBS2YsV0FBaEQsRUFBNEQsSUFBNUQ7QUFDQSxTQUFLTixJQUFMLENBQVVtQixFQUFWLENBQWF2QixFQUFFLENBQUNNLElBQUgsQ0FBUWtCLFNBQVIsQ0FBa0JFLFNBQS9CLEVBQXlDLEtBQUtkLFNBQTlDLEVBQXdELElBQXhEO0FBQ0EsU0FBS0wsS0FBTCxDQUFXZ0IsRUFBWCxDQUFjdkIsRUFBRSxDQUFDTSxJQUFILENBQVFrQixTQUFSLENBQWtCQyxXQUFoQyxFQUE0QyxLQUFLWixZQUFqRCxFQUE4RCxJQUE5RDtBQUNBLFNBQUtOLEtBQUwsQ0FBV2dCLEVBQVgsQ0FBY3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBaEMsRUFBMEMsS0FBS1gsVUFBL0MsRUFBMEQsSUFBMUQ7QUFDQSxTQUFLUCxFQUFMLENBQVFlLEVBQVIsQ0FBV3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBN0IsRUFBeUMsS0FBS1QsU0FBOUMsRUFBd0QsSUFBeEQ7QUFDQSxTQUFLUixFQUFMLENBQVFlLEVBQVIsQ0FBV3ZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBN0IsRUFBdUMsS0FBS1IsT0FBNUMsRUFBb0QsSUFBcEQ7QUFDQSxTQUFLVCxJQUFMLENBQVVjLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkMsV0FBL0IsRUFBMkMsS0FBS04sV0FBaEQsRUFBNEQsSUFBNUQ7QUFDQSxTQUFLVixJQUFMLENBQVVjLEVBQVYsQ0FBYXZCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRa0IsU0FBUixDQUFrQkUsU0FBL0IsRUFBeUMsS0FBS0wsU0FBOUMsRUFBd0QsSUFBeEQ7QUFDSCxHQXBFSSxDQXNFTDs7QUF0RUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsZWZ0OiB7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgICByaWdodDoge1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdXA6e1xyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlLFxyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZG93bjp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxlZnRTdGFydCgpe1xyXG4gICAgICAgIHRoaXMub25MZWZ0ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25MZWZ0RW5kKCl7XHJcbiAgICAgICAgdGhpcy5vbkxlZnQgPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25SaWdodFN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5vblJpZ2h0ID0gdHJ1ZTtcclxuICAgIH0sXHJcblxyXG4gICAgb25SaWdodEVuZCgpe1xyXG4gICAgICAgIHRoaXMub25SaWdodCA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvblVwU3RhcnQoKXtcclxuICAgICAgICB0aGlzLm9uVXAgPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvblVwRW5kKCl7XHJcbiAgICAgICAgdGhpcy5vblVwID0gZmFsc2U7XHJcbiAgICB9LFxyXG5cclxuICAgIG9uRG93blN0YXJ0KCl7XHJcbiAgICAgICAgdGhpcy5vbkRvd24gPSB0cnVlO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkRvd25FbmQoKXtcclxuICAgICAgICB0aGlzLm9uRG93biA9IGZhbHNlO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5vbkxlZnQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uUmlnaHQgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uVXAgPSBmYWxzZTtcclxuICAgICAgICB0aGlzLm9uRG93biA9IGZhbHNlO1xyXG5cclxuICAgICAgICB0aGlzLmxlZnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vbkxlZnRTdGFydCx0aGlzKTtcclxuICAgICAgICB0aGlzLmxlZnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELHRoaXMub25MZWZ0RW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMucmlnaHQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vblJpZ2h0U3RhcnQsdGhpcyk7XHJcbiAgICAgICAgdGhpcy5yaWdodC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vblJpZ2h0RW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMudXAub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsdGhpcy5vblVwU3RhcnQsdGhpcyk7XHJcbiAgICAgICAgdGhpcy51cC5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vblVwRW5kLHRoaXMpO1xyXG4gICAgICAgIHRoaXMuZG93bi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCx0aGlzLm9uRG93blN0YXJ0LHRoaXMpO1xyXG4gICAgICAgIHRoaXMuZG93bi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsdGhpcy5vbkRvd25FbmQsdGhpcyk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
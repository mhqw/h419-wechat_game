
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/enemy.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '84dab/RQzZF2rsLVY7uWlCv', 'enemy');
// scripts/enemy.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {
    this.dir = Math.random() > 0.5 ? 1 : -1;
    this.xSpeed = 50 + 120 * Math.random();
    this.ySpeed = 50 + 50 * Math.random();
    this.hp = 40 + Math.floor(60 * Math.random());
  },
  start: function start() {
    this.hpLab = this.node.getComponentInChildren(cc.Label);
    this.hpLab.string = this.hp + ''; // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.hp -= 1;

    if (this.hp <= 0) {
      this.node.destroy();
    }

    this.hpLab.string = this.hp + '';
  },
  update: function update(dt) {
    //左右反弹
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.dir = -1;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.dir = 1;
    }

    this.node.x += this.dir * this.xSpeed * dt;
    this.node.y -= this.ySpeed * dt; //再次出现

    if (this.node.y < -800) {
      this.node.y = 800;
    } // console.log(this.node.convertToWorldSpaceAR(this.node.getPosition()));
    // console.log('this.xSpeed = ',this.xSpeed);
    // console.log('this.ySpeed = ',this.ySpeed);
    // console.log('this.dir = ',this.dir);

  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZW5lbXkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJvbkxvYWQiLCJkaXIiLCJNYXRoIiwicmFuZG9tIiwieFNwZWVkIiwieVNwZWVkIiwiaHAiLCJmbG9vciIsInN0YXJ0IiwiaHBMYWIiLCJub2RlIiwiZ2V0Q29tcG9uZW50SW5DaGlsZHJlbiIsIkxhYmVsIiwic3RyaW5nIiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImRlc3Ryb3kiLCJ1cGRhdGUiLCJkdCIsIngiLCJ3aW5TaXplIiwid2lkdGgiLCJ5Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU9MQyxFQUFBQSxNQVBLLG9CQU9JO0FBQ0wsU0FBS0MsR0FBTCxHQUFXQyxJQUFJLENBQUNDLE1BQUwsS0FBZ0IsR0FBaEIsR0FBc0IsQ0FBdEIsR0FBMEIsQ0FBQyxDQUF0QztBQUNBLFNBQUtDLE1BQUwsR0FBYyxLQUFLLE1BQU1GLElBQUksQ0FBQ0MsTUFBTCxFQUF6QjtBQUNBLFNBQUtFLE1BQUwsR0FBYyxLQUFLLEtBQUtILElBQUksQ0FBQ0MsTUFBTCxFQUF4QjtBQUNBLFNBQUtHLEVBQUwsR0FBVSxLQUFLSixJQUFJLENBQUNLLEtBQUwsQ0FBVyxLQUFLTCxJQUFJLENBQUNDLE1BQUwsRUFBaEIsQ0FBZjtBQUNILEdBWkk7QUFjTEssRUFBQUEsS0FkSyxtQkFjRztBQUNKLFNBQUtDLEtBQUwsR0FBYSxLQUFLQyxJQUFMLENBQVVDLHNCQUFWLENBQWlDZixFQUFFLENBQUNnQixLQUFwQyxDQUFiO0FBQ0EsU0FBS0gsS0FBTCxDQUFXSSxNQUFYLEdBQW9CLEtBQUtQLEVBQUwsR0FBVSxFQUE5QixDQUZJLENBR0o7QUFDSCxHQWxCSTtBQW9CTFEsRUFBQUEsZ0JBcEJLLDRCQW9CWUMsS0FwQlosRUFvQm1CQyxJQXBCbkIsRUFvQnlCO0FBQzFCLFNBQUtWLEVBQUwsSUFBVyxDQUFYOztBQUNBLFFBQUksS0FBS0EsRUFBTCxJQUFXLENBQWYsRUFBa0I7QUFDZCxXQUFLSSxJQUFMLENBQVVPLE9BQVY7QUFDSDs7QUFDRCxTQUFLUixLQUFMLENBQVdJLE1BQVgsR0FBb0IsS0FBS1AsRUFBTCxHQUFVLEVBQTlCO0FBQ0gsR0ExQkk7QUE0QkxZLEVBQUFBLE1BNUJLLGtCQTRCRUMsRUE1QkYsRUE0Qk07QUFDUDtBQUNBLFFBQUksS0FBS1QsSUFBTCxDQUFVVSxDQUFWLElBQWV4QixFQUFFLENBQUN5QixPQUFILENBQVdDLEtBQVgsR0FBbUIsQ0FBbkIsR0FBdUIsS0FBS1osSUFBTCxDQUFVWSxLQUFWLEdBQWtCLENBQTVELEVBQStEO0FBQzNELFdBQUtyQixHQUFMLEdBQVcsQ0FBQyxDQUFaO0FBQ0g7O0FBQ0QsUUFBSSxLQUFLUyxJQUFMLENBQVVVLENBQVYsSUFBZSxDQUFDeEIsRUFBRSxDQUFDeUIsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtaLElBQUwsQ0FBVVksS0FBVixHQUFrQixDQUE3RCxFQUFnRTtBQUM1RCxXQUFLckIsR0FBTCxHQUFXLENBQVg7QUFDSDs7QUFFRCxTQUFLUyxJQUFMLENBQVVVLENBQVYsSUFBZSxLQUFLbkIsR0FBTCxHQUFXLEtBQUtHLE1BQWhCLEdBQXlCZSxFQUF4QztBQUNBLFNBQUtULElBQUwsQ0FBVWEsQ0FBVixJQUFlLEtBQUtsQixNQUFMLEdBQWNjLEVBQTdCLENBVk8sQ0FZUDs7QUFDQSxRQUFJLEtBQUtULElBQUwsQ0FBVWEsQ0FBVixHQUFjLENBQUMsR0FBbkIsRUFBd0I7QUFDcEIsV0FBS2IsSUFBTCxDQUFVYSxDQUFWLEdBQWMsR0FBZDtBQUNILEtBZk0sQ0FnQlA7QUFDQTtBQUNBO0FBQ0E7O0FBQ0g7QUFoREksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICB0aGlzLmRpciA9IE1hdGgucmFuZG9tKCkgPiAwLjUgPyAxIDogLTE7XHJcbiAgICAgICAgdGhpcy54U3BlZWQgPSA1MCArIDEyMCAqIE1hdGgucmFuZG9tKCk7XHJcbiAgICAgICAgdGhpcy55U3BlZWQgPSA1MCArIDUwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICB0aGlzLmhwID0gNDAgKyBNYXRoLmZsb29yKDYwICogTWF0aC5yYW5kb20oKSk7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuaHBMYWIgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50SW5DaGlsZHJlbihjYy5MYWJlbCk7XHJcbiAgICAgICAgdGhpcy5ocExhYi5zdHJpbmcgPSB0aGlzLmhwICsgJyc7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2codGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUih0aGlzLm5vZGUuZ2V0UG9zaXRpb24oKSkpO1xyXG4gICAgfSxcclxuXHJcbiAgICBvbkNvbGxpc2lvbkVudGVyKG90aGVyLCBzZWxmKSB7XHJcbiAgICAgICAgdGhpcy5ocCAtPSAxO1xyXG4gICAgICAgIGlmICh0aGlzLmhwIDw9IDApIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5ocExhYi5zdHJpbmcgPSB0aGlzLmhwICsgJyc7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIC8v5bem5Y+z5Y+N5by5XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54ID49IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLmRpciA9IC0xO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnggPD0gLWNjLndpblNpemUud2lkdGggLyAyICsgdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLmRpciA9IDE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLm5vZGUueCArPSB0aGlzLmRpciAqIHRoaXMueFNwZWVkICogZHQ7XHJcbiAgICAgICAgdGhpcy5ub2RlLnkgLT0gdGhpcy55U3BlZWQgKiBkdDtcclxuXHJcbiAgICAgICAgLy/lho3mrKHlh7rnjrBcclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPCAtODAwKSB7XHJcbiAgICAgICAgICAgIHRoaXMubm9kZS55ID0gODAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKHRoaXMubm9kZS5nZXRQb3NpdGlvbigpKSk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMueFNwZWVkID0gJyx0aGlzLnhTcGVlZCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMueVNwZWVkID0gJyx0aGlzLnlTcGVlZCk7XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coJ3RoaXMuZGlyID0gJyx0aGlzLmRpcik7XHJcbiAgICB9LFxyXG59KTtcclxuIl19
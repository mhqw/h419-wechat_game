
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/enemyMgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c29852ieOFAz44vlMnx/RaC', 'enemyMgr');
// scripts/enemyMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    enemy: {
      type: cc.Prefab,
      "default": null
    },
    newEnemyDuration: 6
  },
  creatOneEnemy: function creatOneEnemy() {
    var e = cc.instantiate(this.enemy);
    this.node.addChild(e);
    e.x = -300 + 600 * Math.random();
    e.y = 750;
  },
  start: function start() {
    this.schedule(this.creatOneEnemy, this.newEnemyDuration); // this.creatOneEnemy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZW5lbXlNZ3IuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJlbmVteSIsInR5cGUiLCJQcmVmYWIiLCJuZXdFbmVteUR1cmF0aW9uIiwiY3JlYXRPbmVFbmVteSIsImUiLCJpbnN0YW50aWF0ZSIsIm5vZGUiLCJhZGRDaGlsZCIsIngiLCJNYXRoIiwicmFuZG9tIiwieSIsInN0YXJ0Iiwic2NoZWR1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUM7QUFDRkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRFA7QUFFRixpQkFBUztBQUZQLEtBREU7QUFLUkMsSUFBQUEsZ0JBQWdCLEVBQUU7QUFMVixHQUhQO0FBV0xDLEVBQUFBLGFBWEssMkJBV1U7QUFDWCxRQUFJQyxDQUFDLEdBQUdULEVBQUUsQ0FBQ1UsV0FBSCxDQUFlLEtBQUtOLEtBQXBCLENBQVI7QUFDQSxTQUFLTyxJQUFMLENBQVVDLFFBQVYsQ0FBbUJILENBQW5CO0FBQ0FBLElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNLENBQUMsR0FBRCxHQUFPLE1BQU1DLElBQUksQ0FBQ0MsTUFBTCxFQUFuQjtBQUNBTixJQUFBQSxDQUFDLENBQUNPLENBQUYsR0FBTSxHQUFOO0FBQ0gsR0FoQkk7QUFrQkxDLEVBQUFBLEtBbEJLLG1CQWtCSTtBQUNMLFNBQUtDLFFBQUwsQ0FBYyxLQUFLVixhQUFuQixFQUFpQyxLQUFLRCxnQkFBdEMsRUFESyxDQUVMO0FBQ0g7QUFyQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBlbmVteTp7XHJcbiAgICAgICAgICAgIHR5cGU6IGNjLlByZWZhYixcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG5ld0VuZW15RHVyYXRpb246IDYsXHJcbiAgICB9LFxyXG5cclxuICAgIGNyZWF0T25lRW5lbXkoKXtcclxuICAgICAgICB2YXIgZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZW5lbXkpO1xyXG4gICAgICAgIHRoaXMubm9kZS5hZGRDaGlsZChlKTtcclxuICAgICAgICBlLnggPSAtMzAwICsgNjAwICogTWF0aC5yYW5kb20oKTtcclxuICAgICAgICBlLnkgPSA3NTA7XHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlKHRoaXMuY3JlYXRPbmVFbmVteSx0aGlzLm5ld0VuZW15RHVyYXRpb24pO1xyXG4gICAgICAgIC8vIHRoaXMuY3JlYXRPbmVFbmVteSgpO1xyXG4gICAgfSxcclxuXHJcbn0pO1xyXG4iXX0=
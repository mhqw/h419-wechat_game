
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/player_hp_mgr.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8aaa8ubRG9B1JH4VeMARY3p', 'player_hp_mgr');
// scripts/player_hp_mgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player_hp: {
      type: cc.Label,
      "default": null
    }
  },
  onLoad: function onLoad() {
    this.hp = 5 + Math.floor(7 * Math.random());
    this.player_hp.string = this.hp;
  },
  //start () {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.hp -= 1;

    if (this.hp <= 0) {
      cc.director.loadScene('gameover_scene');
    }

    this.player_hp.string = this.hp + '';
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccGxheWVyX2hwX21nci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInBsYXllcl9ocCIsInR5cGUiLCJMYWJlbCIsIm9uTG9hZCIsImhwIiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwic3RyaW5nIiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImRpcmVjdG9yIiwibG9hZFNjZW5lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsU0FBUyxFQUFDO0FBQ05DLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQURIO0FBRU4saUJBQVM7QUFGSDtBQURGLEdBSFA7QUFVTEMsRUFBQUEsTUFWSyxvQkFVSztBQUNOLFNBQUtDLEVBQUwsR0FBVSxJQUFJQyxJQUFJLENBQUNDLEtBQUwsQ0FBVyxJQUFJRCxJQUFJLENBQUNFLE1BQUwsRUFBZixDQUFkO0FBQ0EsU0FBS1AsU0FBTCxDQUFlUSxNQUFmLEdBQXdCLEtBQUtKLEVBQTdCO0FBQ0gsR0FiSTtBQWVMO0FBRUFLLEVBQUFBLGdCQWpCSyw0QkFpQllDLEtBakJaLEVBaUJrQkMsSUFqQmxCLEVBaUJ1QjtBQUN4QixTQUFLUCxFQUFMLElBQVcsQ0FBWDs7QUFDQSxRQUFJLEtBQUtBLEVBQUwsSUFBVyxDQUFmLEVBQWtCO0FBQ2RSLE1BQUFBLEVBQUUsQ0FBQ2dCLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixnQkFBdEI7QUFDSDs7QUFDRCxTQUFLYixTQUFMLENBQWVRLE1BQWYsR0FBd0IsS0FBS0osRUFBTCxHQUFVLEVBQWxDO0FBQ0gsR0F2QkksQ0F5Qkw7O0FBekJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgcGxheWVyX2hwOntcclxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWwsXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMuaHAgPSA1ICsgTWF0aC5mbG9vcig3ICogTWF0aC5yYW5kb20oKSk7XHJcbiAgICAgICAgdGhpcy5wbGF5ZXJfaHAuc3RyaW5nID0gdGhpcy5ocDtcclxuICAgIH0sXHJcblxyXG4gICAgLy9zdGFydCAoKSB7fSxcclxuXHJcbiAgICBvbkNvbGxpc2lvbkVudGVyKG90aGVyLHNlbGYpe1xyXG4gICAgICAgIHRoaXMuaHAgLT0gMTtcclxuICAgICAgICBpZiAodGhpcy5ocCA8PSAwKSB7XHJcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZ2FtZW92ZXJfc2NlbmUnKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5wbGF5ZXJfaHAuc3RyaW5nID0gdGhpcy5ocCArICcnO1xyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/prevent_out.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '49b717oGXdOE76zneMmdmuQ', 'prevent_out');
// scripts/prevent_out.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    //防止跑出屏幕外
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }

    if (this.node.y >= cc.winSize.height / 2 - this.node.height / 2) {
      this.node.y = cc.winSize.height / 2 - this.node.height / 2;
    }

    if (this.node.y <= -cc.winSize.height / 2 + this.node.height / 2) {
      this.node.y = -cc.winSize.height / 2 + this.node.height / 2;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccHJldmVudF9vdXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwibm9kZSIsIngiLCJ3aW5TaXplIiwid2lkdGgiLCJ5IiwiaGVpZ2h0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsQ0FDUjtBQUNBO0FBQ0E7QUFDQTtBQUpRLEdBSFA7QUFVTDtBQUVBO0FBRUFDLEVBQUFBLEtBZEssbUJBY0csQ0FDUCxDQWZJO0FBaUJMQyxFQUFBQSxNQWpCSyxrQkFpQkVDLEVBakJGLEVBaUJNO0FBQ1A7QUFDQSxRQUFJLEtBQUtDLElBQUwsQ0FBVUMsQ0FBVixJQUFlUixFQUFFLENBQUNTLE9BQUgsQ0FBV0MsS0FBWCxHQUFtQixDQUFuQixHQUF1QixLQUFLSCxJQUFMLENBQVVHLEtBQVYsR0FBa0IsQ0FBNUQsRUFBK0Q7QUFDM0QsV0FBS0gsSUFBTCxDQUFVQyxDQUFWLEdBQWNSLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXQyxLQUFYLEdBQW1CLENBQW5CLEdBQXVCLEtBQUtILElBQUwsQ0FBVUcsS0FBVixHQUFrQixDQUF2RDtBQUNIOztBQUNELFFBQUksS0FBS0gsSUFBTCxDQUFVQyxDQUFWLElBQWUsQ0FBQ1IsRUFBRSxDQUFDUyxPQUFILENBQVdDLEtBQVosR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS0gsSUFBTCxDQUFVRyxLQUFWLEdBQWtCLENBQTdELEVBQWdFO0FBQzVELFdBQUtILElBQUwsQ0FBVUMsQ0FBVixHQUFjLENBQUNSLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXQyxLQUFaLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtILElBQUwsQ0FBVUcsS0FBVixHQUFrQixDQUF4RDtBQUNIOztBQUNELFFBQUksS0FBS0gsSUFBTCxDQUFVSSxDQUFWLElBQWVYLEVBQUUsQ0FBQ1MsT0FBSCxDQUFXRyxNQUFYLEdBQW9CLENBQXBCLEdBQXdCLEtBQUtMLElBQUwsQ0FBVUssTUFBVixHQUFtQixDQUE5RCxFQUFpRTtBQUM3RCxXQUFLTCxJQUFMLENBQVVJLENBQVYsR0FBY1gsRUFBRSxDQUFDUyxPQUFILENBQVdHLE1BQVgsR0FBb0IsQ0FBcEIsR0FBd0IsS0FBS0wsSUFBTCxDQUFVSyxNQUFWLEdBQW1CLENBQXpEO0FBQ0g7O0FBQ0QsUUFBSSxLQUFLTCxJQUFMLENBQVVJLENBQVYsSUFBZSxDQUFDWCxFQUFFLENBQUNTLE9BQUgsQ0FBV0csTUFBWixHQUFxQixDQUFyQixHQUF5QixLQUFLTCxJQUFMLENBQVVLLE1BQVYsR0FBbUIsQ0FBL0QsRUFBa0U7QUFDOUQsV0FBS0wsSUFBTCxDQUFVSSxDQUFWLEdBQWMsQ0FBQ1gsRUFBRSxDQUFDUyxPQUFILENBQVdHLE1BQVosR0FBcUIsQ0FBckIsR0FBeUIsS0FBS0wsSUFBTCxDQUFVSyxNQUFWLEdBQW1CLENBQTFEO0FBQ0g7QUFDSjtBQS9CSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIHBsYXllcjp7XHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLk5vZGUsXHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgLy8gfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZShkdCkge1xyXG4gICAgICAgIC8v6Ziy5q2i6LeR5Ye65bGP5bmV5aSWXHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54ID49IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueCA9IGNjLndpblNpemUud2lkdGggLyAyIC0gdGhpcy5ub2RlLndpZHRoIC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS54IDw9IC1jYy53aW5TaXplLndpZHRoIC8gMiArIHRoaXMubm9kZS53aWR0aCAvIDIpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnggPSAtY2Mud2luU2l6ZS53aWR0aCAvIDIgKyB0aGlzLm5vZGUud2lkdGggLyAyO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodGhpcy5ub2RlLnkgPj0gY2Mud2luU2l6ZS5oZWlnaHQgLyAyIC0gdGhpcy5ub2RlLmhlaWdodCAvIDIpIHtcclxuICAgICAgICAgICAgdGhpcy5ub2RlLnkgPSBjYy53aW5TaXplLmhlaWdodCAvIDIgLSB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS55IDw9IC1jYy53aW5TaXplLmhlaWdodCAvIDIgKyB0aGlzLm5vZGUuaGVpZ2h0IC8gMikge1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUueSA9IC1jYy53aW5TaXplLmhlaWdodCAvIDIgKyB0aGlzLm5vZGUuaGVpZ2h0IC8gMjtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG59KTtcclxuIl19

require('./assets/scripts/bullet');
require('./assets/scripts/bulletMgr');
require('./assets/scripts/camera_bk');
require('./assets/scripts/ctrl_player');
require('./assets/scripts/ctrl_player_withrocker ');
require('./assets/scripts/ctrl_player_withwasd');
require('./assets/scripts/ctrl_player_withwasd_p2');
require('./assets/scripts/enemy');
require('./assets/scripts/enemyMgr');
require('./assets/scripts/player_hp_mgr');
require('./assets/scripts/preload_choosectrl_scene');
require('./assets/scripts/preload_game_scene');
require('./assets/scripts/preload_game_withro_scene');
require('./assets/scripts/preload_game_withwasd_scene');
require('./assets/scripts/preload_gameover_scene');
require('./assets/scripts/prevent_out');
require('./assets/scripts/test');

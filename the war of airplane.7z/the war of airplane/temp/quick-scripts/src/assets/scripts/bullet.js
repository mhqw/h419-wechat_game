"use strict";
cc._RF.push(module, 'b8094Ib0CVEMZBDniK7KkHz', 'bullet');
// scripts/bullet.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    speed: 800,
    pool: null
  },
  reuse: function reuse(pool) {
    this.pool = pool;
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.pool.put(this.node);
  },
  update: function update(dt) {
    this.node.y += this.speed * dt;

    if (this.node.y > 800) {
      this.pool.put(this.node);
    }
  }
});

cc._RF.pop();
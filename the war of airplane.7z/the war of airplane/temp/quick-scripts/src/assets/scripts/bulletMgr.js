"use strict";
cc._RF.push(module, '5a147DfE6BP1KMMoai9SJjZ', 'bulletMgr');
// scripts/bulletMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    bullet: {
      type: cc.Prefab,
      "default": null
    },
    player: {
      type: cc.Node,
      "default": null
    },
    shootDuration: 0.3
  },
  onLoad: function onLoad() {
    cc.director.getCollisionManager().enabled = true;
    this.pool = new cc.NodePool('bullet');

    for (var i = 0; i < 100; i++) {
      this.pool.put(cc.instantiate(this.bullet));
    }
  },
  start: function start() {
    this.schedule(this.creatManyBullet, this.shootDuration);
  },
  creatManyBullet: function creatManyBullet() {
    var px = this.player.x;
    var py = this.player.y;
    var offset = 55;
    this.creatOneBullet(px, py);
    this.creatOneBullet(px - offset, py);
    this.creatOneBullet(px + offset, py);
  },
  creatOneBullet: function creatOneBullet(x, y) {
    var b = this.pool.get(this.pool);
    if (!b) b = cc.instantiate(this.bullet);
    b.parent = this.node;
    b.x = x;
    b.y = y + 50;
  } //update(dt) {},

});

cc._RF.pop();
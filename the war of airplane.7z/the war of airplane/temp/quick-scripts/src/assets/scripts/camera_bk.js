"use strict";
cc._RF.push(module, 'd958dgWyJRNG5iVSuSy+uNo', 'camera_bk');
// scripts/camera_bk.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // onLoad () {},
  start: function start() {
    var _this = this;

    cc.tween(this.node).repeatForever(cc.tween().to(10, {
      position: cc.v2(0, 1440)
    }).call(function () {
      _this.node.y = 0;
    })).start();
  } // update (dt) {},

});

cc._RF.pop();
"use strict";
cc._RF.push(module, 'd0f17Uy0qRN6o7NUeQlamc0', 'ctrl_player');
// scripts/ctrl_player.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onTouchStart: function onTouchStart(t) {},
  onTouchMove: function onTouchMove(t) {
    var delta = t.getDelta();
    this.node.x += delta.x;
    this.node.y += delta.y;
  },
  onTouchEnd: function onTouchEnd(t) {},
  start: function start() {
    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
    this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
  },
  update: function update(dt) {
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }
  }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, 'b38acFBUl5MdY2DzGXp3MXp', 'ctrl_player_withrocker ');
// scripts/ctrl_player_withrocker .ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.player = null;
        _this.rocker = null;
        _this.rocker_stick = null;
        // @property(number)
        // speed_ctrl: number = 1;
        _this.rocker_max_r = 60;
        _this.rocker_touched = false;
        _this.touch_location = null;
        _this.touch_position = null;
        _this.touch_distance = null;
        _this.rocker_x = null;
        _this.rocker_y = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    Main.prototype.onLoad = function () {
        this.rocker.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.rocker.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.rocker.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
        this.rocker.on(cc.Node.EventType.TOUCH_END, this.onTouchCancel, this);
    };
    Main.prototype.start = function () {
    };
    Main.prototype.onTouchStart = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
        if (this.touch_distance <= this.rocker_max_r) {
            this.rocker_touched = true;
        }
    };
    Main.prototype.onTouchMove = function (e) {
        this.touch_location = e.getLocation();
        this.touch_position = this.rocker.convertToNodeSpaceAR(this.touch_location);
        this.touch_distance = this.touch_position.len();
    };
    Main.prototype.onTouchCancel = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.onTouchEnd = function (e) {
        this.touch_location = e.getLocation();
        this.rocker_touched = false;
        this.rocker_stick.setPosition(this.rocker.getPosition());
    };
    Main.prototype.update = function (dt) {
        if (this.rocker_touched) {
            if (this.touch_distance <= this.rocker_max_r) {
                //摇杆在圈内
                this.rocker_stick.x = this.touch_position.x + this.rocker.x;
                this.rocker_stick.y = this.touch_position.y + this.rocker.y;
            }
            else {
                //摇杆在圈边
                var p = this.touch_position.normalize();
                this.rocker_stick.x = p.x * this.rocker_max_r + this.rocker.x;
                this.rocker_stick.y = p.y * this.rocker_max_r + this.rocker.y;
            }
        }
        this.rocker_x = this.rocker_stick.x - this.rocker.x;
        this.rocker_y = this.rocker_stick.y - this.rocker.y;
        this.player.x += 0.05 * this.rocker_x;
        this.player.y += 0.05 * this.rocker_y;
    };
    __decorate([
        property(cc.Node)
    ], Main.prototype, "player", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker", void 0);
    __decorate([
        property(cc.Node)
    ], Main.prototype, "rocker_stick", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
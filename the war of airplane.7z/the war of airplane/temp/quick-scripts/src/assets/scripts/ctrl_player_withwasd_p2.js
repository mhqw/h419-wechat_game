"use strict";
cc._RF.push(module, 'e7fabmMsQFPCKrq+7KgKuXb', 'ctrl_player_withwasd_p2');
// scripts/ctrl_player_withwasd_p2.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    left: {
      type: cc.Node,
      "default": null
    },
    right: {
      type: cc.Node,
      "default": null
    },
    up: {
      type: cc.Node,
      "default": null
    },
    down: {
      type: cc.Node,
      "default": null
    }
  },
  onLeftStart: function onLeftStart() {
    this.onLeft = true;
  },
  onLeftEnd: function onLeftEnd() {
    this.onLeft = false;
  },
  onRightStart: function onRightStart() {
    this.onRight = true;
  },
  onRightEnd: function onRightEnd() {
    this.onRight = false;
  },
  onUpStart: function onUpStart() {
    this.onUp = true;
  },
  onUpEnd: function onUpEnd() {
    this.onUp = false;
  },
  onDownStart: function onDownStart() {
    this.onDown = true;
  },
  onDownEnd: function onDownEnd() {
    this.onDown = false;
  },
  start: function start() {
    this.onLeft = false;
    this.onRight = false;
    this.onUp = false;
    this.onDown = false;
    this.left.on(cc.Node.EventType.TOUCH_START, this.onLeftStart, this);
    this.left.on(cc.Node.EventType.TOUCH_END, this.onLeftEnd, this);
    this.right.on(cc.Node.EventType.TOUCH_START, this.onRightStart, this);
    this.right.on(cc.Node.EventType.TOUCH_END, this.onRightEnd, this);
    this.up.on(cc.Node.EventType.TOUCH_START, this.onUpStart, this);
    this.up.on(cc.Node.EventType.TOUCH_END, this.onUpEnd, this);
    this.down.on(cc.Node.EventType.TOUCH_START, this.onDownStart, this);
    this.down.on(cc.Node.EventType.TOUCH_END, this.onDownEnd, this);
  } // update (dt) {},

});

cc._RF.pop();
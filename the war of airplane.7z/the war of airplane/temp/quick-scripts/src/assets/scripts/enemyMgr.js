"use strict";
cc._RF.push(module, 'c29852ieOFAz44vlMnx/RaC', 'enemyMgr');
// scripts/enemyMgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    enemy: {
      type: cc.Prefab,
      "default": null
    },
    newEnemyDuration: 6
  },
  creatOneEnemy: function creatOneEnemy() {
    var e = cc.instantiate(this.enemy);
    this.node.addChild(e);
    e.x = -300 + 600 * Math.random();
    e.y = 750;
  },
  start: function start() {
    this.schedule(this.creatOneEnemy, this.newEnemyDuration); // this.creatOneEnemy();
  }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '8aaa8ubRG9B1JH4VeMARY3p', 'player_hp_mgr');
// scripts/player_hp_mgr.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    player_hp: {
      type: cc.Label,
      "default": null
    }
  },
  onLoad: function onLoad() {
    this.hp = 5 + Math.floor(7 * Math.random());
    this.player_hp.string = this.hp;
  },
  //start () {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    this.hp -= 1;

    if (this.hp <= 0) {
      cc.director.loadScene('gameover_scene');
    }

    this.player_hp.string = this.hp + '';
  } // update (dt) {},

});

cc._RF.pop();
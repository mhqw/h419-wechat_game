"use strict";
cc._RF.push(module, '04486d+PyZOWYqz6hgNDzUm', 'preload_choosectrl_scene');
// scripts/preload_choosectrl_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('choosectrl_scene');
  },
  enterChoosectrl_scene: function enterChoosectrl_scene() {
    cc.director.loadScene('choosectrl_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
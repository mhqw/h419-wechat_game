"use strict";
cc._RF.push(module, '8a448yQuLhNSK7dWkIlVNyx', 'preload_game_scene');
// scripts/preload_game_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('game_scene');
  },
  enterGame_scene: function enterGame_scene() {
    cc.director.loadScene('game_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
"use strict";
cc._RF.push(module, 'fee3bb4mHdKH7BC1GrMifFc', 'preload_game_withro_scene');
// scripts/preload_game_withro_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('game_withrocker_scene');
  },
  enterGame_withrocker_scene: function enterGame_withrocker_scene() {
    cc.director.loadScene('game_withrocker_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
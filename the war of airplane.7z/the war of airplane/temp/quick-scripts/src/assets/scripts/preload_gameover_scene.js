"use strict";
cc._RF.push(module, 'f27ed1wkO1D1YrManjtxmGk', 'preload_gameover_scene');
// scripts/preload_gameover_scene.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.director.preloadScene('gameover_scene');
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
"use strict";
cc._RF.push(module, '49b717oGXdOE76zneMmdmuQ', 'prevent_out');
// scripts/prevent_out.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {// player:{
    //     type: cc.Node,
    //     default: null,
    // }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    //防止跑出屏幕外
    if (this.node.x >= cc.winSize.width / 2 - this.node.width / 2) {
      this.node.x = cc.winSize.width / 2 - this.node.width / 2;
    }

    if (this.node.x <= -cc.winSize.width / 2 + this.node.width / 2) {
      this.node.x = -cc.winSize.width / 2 + this.node.width / 2;
    }

    if (this.node.y >= cc.winSize.height / 2 - this.node.height / 2) {
      this.node.y = cc.winSize.height / 2 - this.node.height / 2;
    }

    if (this.node.y <= -cc.winSize.height / 2 + this.node.height / 2) {
      this.node.y = -cc.winSize.height / 2 + this.node.height / 2;
    }
  }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '8d93f/kJcRDtLDg0GMZPuJn', 'test');
// scripts/test.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  callfunc: function callfunc() {
    console.log("hello");
  },
  start: function start() {
    this.schedule(this.callfunc, 0.3);
  } // update (dt) {},

});

cc._RF.pop();